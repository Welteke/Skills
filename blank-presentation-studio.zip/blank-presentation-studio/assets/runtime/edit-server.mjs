import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const toolDir=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(toolDir,'..');
const port=Number(process.env.BLANK_EDIT_PORT||4179);
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.woff2':'font/woff2'};
const readBody=req=>new Promise((resolve,reject)=>{let data='';req.on('data',c=>data+=c);req.on('end',()=>{try{resolve(JSON.parse(data||'{}'))}catch(error){reject(error)}});req.on('error',reject)});
const safe=p=>{const resolved=path.resolve(root,'.'+decodeURIComponent(p.split('?')[0]));if(!resolved.startsWith(root))throw new Error('Ungültiger Pfad');return resolved};
async function updatePresentation(mutator){const file=path.join(root,'metadata','presentation.json');const data=JSON.parse(await fs.readFile(file,'utf8'));mutator(data);await fs.writeFile(file,JSON.stringify(data,null,2)+'\n','utf8');return data}
async function bake(edits,notes){let html=await fs.readFile(path.join(root,'index.html'),'utf8');for(const [id,value] of Object.entries(edits||{})){const escaped=id.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const re=new RegExp(`(<([a-z0-9-]+)[^>]*data-edit-id=["']${escaped}["'][^>]*>)[\\s\\S]*?(<\\/\\2>)`,'i');html=html.replace(re,`$1${value}$3`)}if(notes){const payload=JSON.stringify({...JSON.parse(html.match(/<script id="deck-data" type="application\/json">([\s\S]*?)<\/script>/)?.[1]||'{}'),notes}).replace(/</g,'\\u003c');html=html.replace(/(<script id="deck-data" type="application\/json">)[\s\S]*?(<\/script>)/,`$1${payload}$2`)}await fs.writeFile(path.join(root,'index.html'),html,'utf8')}
const server=http.createServer(async(req,res)=>{try{
  if(req.method==='POST'&&req.url==='/api/save'){const body=await readBody(req);const data=await updatePresentation(d=>{d.contentEdits=body.edits||{};d.notes=body.notes||d.notes||[]});await bake(body.edits,data.notes);res.writeHead(200,{'content-type':'application/json'});return res.end('{"ok":true}')}
  if(req.method==='POST'&&req.url==='/api/notes'){const body=await readBody(req);const data=await updatePresentation(d=>d.notes=body.notes||[]);await bake(data.contentEdits||{},data.notes);res.writeHead(200,{'content-type':'application/json'});return res.end('{"ok":true}')}
  let file=safe(req.url==='/'?'/index.html':req.url);const stat=await fs.stat(file);if(stat.isDirectory())file=path.join(file,'index.html');const content=await fs.readFile(file);res.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream','cache-control':'no-store'});res.end(content)
}catch(error){res.writeHead(error.code==='ENOENT'?404:500,{'content-type':'text/plain; charset=utf-8'});res.end(error.message)}});
server.listen(port,'127.0.0.1',()=>console.log(`BlankPresentationStudio Editor: http://127.0.0.1:${server.address().port}`));
