class BlankDeckRuntime {
  constructor() {
    this.slides = [...document.querySelectorAll('.slide')];
    this.index = 0;
    this.fragments = new Map();
    this.stage = document.querySelector('.deck-stage');
    this.channel = new BroadcastChannel(`blank-deck-${document.body.dataset.deckId || 'default'}`);
    this.isPresenter = new URLSearchParams(location.search).get('presenter') === '1';
    this.editEnabled = document.body.dataset.editEnabled === 'true';
    this.started = Date.now();
    this.lastWheel = 0;
    this.activeNote = null;
    this.data = this.readData();

    document.documentElement.style.setProperty('--slide-count', String(this.slides.length));
    this.slides.forEach((slide, index) => slide.style.setProperty('--progress-index', String(index)));

    this.bindChannel();
    this.bindKeys();
    this.bindPointer();
    this.bindTouch();
    this.bindWheel();
    this.bindControls();
    this.scale();
    addEventListener('resize', () => this.scale());

    if (this.isPresenter) this.mountPresenter();
    else this.show(0, false);
    this.channel.postMessage({ type: 'hello' });
  }

  readData() {
    try {
      return JSON.parse(document.getElementById('deck-data')?.textContent || '{}');
    } catch {
      return { notes: [] };
    }
  }

  bindChannel() {
    this.channel.onmessage = event => {
      const message = event.data || {};
      if (message.type === 'state') {
        this.index = message.index;
        this.fragments = new Map(message.fragments || []);
        this.isPresenter ? this.renderPresenter() : this.show(this.index, false);
      }
      if (message.type === 'hello' && !this.isPresenter) this.broadcast();
    };
  }

  broadcast() {
    this.channel.postMessage({
      type: 'state',
      index: this.index,
      fragments: [...this.fragments],
    });
  }

  scale() {
    if (this.isPresenter) {
      this.scalePresenter();
      return;
    }
    const factor = Math.min(innerWidth / 1920, innerHeight / 1080);
    this.stage.style.transform = `translate(${(innerWidth - 1920 * factor) / 2}px,${(innerHeight - 1080 * factor) / 2}px) scale(${factor})`;
  }

  bindKeys() {
    addEventListener('keydown', event => {
      const saveShortcut = (event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's';
      if (saveShortcut && (document.body.classList.contains('editing') || this.isPresenter)) {
        event.preventDefault();
        this.isPresenter ? this.savePresenterNotes() : this.saveEdits();
        return;
      }
      if (event.target?.isContentEditable) return;
      if (['ArrowRight', 'PageDown', ' '].includes(event.key)) {
        event.preventDefault();
        this.next();
      } else if (['ArrowLeft', 'PageUp'].includes(event.key)) {
        event.preventDefault();
        this.prev();
      } else if (event.key === 'Home') {
        this.show(0);
      } else if (event.key === 'End') {
        this.show(this.slides.length - 1);
      } else if ((event.key === 'p' || event.key === 'P') && !this.isPresenter) {
        const presenterUrl = new URL(location.href);
        presenterUrl.searchParams.set('presenter', '1');
        open(presenterUrl.href, 'blank-presenter');
      } else if ((event.key === 'e' || event.key === 'E') && !this.isPresenter) {
        this.toggleEdit();
      }
    });
  }

  bindPointer() {
    const cursor = document.querySelector('.presentation-cursor');
    if (!cursor || this.isPresenter) return;
    addEventListener('pointermove', event => {
      cursor.style.transform = `translate(${event.clientX}px,${event.clientY}px) translate(-50%,-50%)`;
      cursor.classList.add('visible');
      cursor.classList.toggle('interactive', Boolean(event.target.closest('a,button')));
      document.documentElement.style.setProperty('--cursor-x', `${event.clientX / innerWidth * 100}%`);
      document.documentElement.style.setProperty('--cursor-y', `${event.clientY / innerHeight * 100}%`);
    });
  }

  bindTouch() {
    let startX = 0;
    addEventListener('touchstart', event => {
      startX = event.changedTouches[0].screenX;
    }, { passive: true });
    addEventListener('touchend', event => {
      const delta = event.changedTouches[0].screenX - startX;
      if (delta < -70) this.next();
      if (delta > 70) this.prev();
    }, { passive: true });
  }

  bindWheel() {
    if (this.isPresenter) return;
    addEventListener('wheel', event => {
      if (document.body.classList.contains('editing') || Math.abs(event.deltaY) < 12) return;
      const now = Date.now();
      if (now - this.lastWheel < 450) return;
      this.lastWheel = now;
      event.deltaY > 0 ? this.next() : this.prev();
    }, { passive: true });
  }

  bindControls() {
    document.getElementById('prevBtn')?.addEventListener('click', () => this.prev());
    document.getElementById('nextBtn')?.addEventListener('click', () => this.next());
    document.getElementById('saveEdits')?.addEventListener('click', () => this.saveEdits());
    document.getElementById('exitEdit')?.addEventListener('click', () => this.toggleEdit(false));
  }

  slideFragments(index) {
    return [...(this.slides[index]?.querySelectorAll('[data-fragment]') || [])];
  }

  applyFragments(index) {
    const visible = this.fragments.get(index) || 0;
    this.slideFragments(index).forEach((element, fragmentIndex) => {
      element.classList.toggle('shown', fragmentIndex < visible);
    });
  }

  show(index, send = true) {
    this.index = Math.max(0, Math.min(index, this.slides.length - 1));
    this.slides.forEach((slide, slideIndex) => {
      const active = slideIndex === this.index;
      slide.classList.toggle('active', active);
      slide.classList.toggle('visible', active);
    });
    this.applyFragments(this.index);
    if (this.isPresenter) this.renderPresenter();
    if (send) this.broadcast();
  }

  next() {
    if (this.isPresenter) this.capturePresenterNotes();
    const visible = this.fragments.get(this.index) || 0;
    if (visible < this.slideFragments(this.index).length) {
      this.fragments.set(this.index, visible + 1);
      this.applyFragments(this.index);
      this.renderPresenter();
      this.broadcast();
      return;
    }
    this.show(this.index + 1);
  }

  prev() {
    if (this.isPresenter) this.capturePresenterNotes();
    const visible = this.fragments.get(this.index) || 0;
    if (visible > 0) {
      this.fragments.set(this.index, visible - 1);
      this.applyFragments(this.index);
      this.renderPresenter();
      this.broadcast();
      return;
    }
    this.show(this.index - 1);
  }

  toggleEdit(force) {
    if (!this.editEnabled) {
      alert('Bearbeitung ist in dieser Ausgabe deaktiviert. Starte edit-praesi.cmd im Arbeitsordner.');
      return;
    }
    const enabled = force ?? !document.body.classList.contains('editing');
    document.body.classList.toggle('editing', enabled);
    document.querySelectorAll('[data-edit-id]').forEach(element => {
      element.contentEditable = enabled ? 'true' : 'false';
    });
  }

  async saveEdits() {
    const edits = {};
    document.querySelectorAll('[data-edit-id]').forEach(element => {
      edits[element.dataset.editId] = element.innerHTML;
    });
    const response = await fetch('/api/save', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ edits, notes: this.data.notes || [] }),
    });
    if (!response.ok) throw new Error(await response.text());
  }

  mountPresenter() {
    document.body.classList.add('presenter-mode');
    document.body.insertAdjacentHTML('beforeend', `
      <main class="presenter-shell">
        <section class="presenter-current"><div class="presenter-preview-stage"></div></section>
        <aside class="presenter-notes">
          <div class="presenter-meta"><span id="presenterCount"></span><span id="presenterTime"></span></div>
          <h2 id="presenterTitle">Notizen</h2>
          <div class="presenter-note-toolbar" ${this.editEnabled ? '' : 'hidden'}>
            <button type="button" data-note-action="add">+ Stichpunkt</button>
            <button type="button" data-note-action="bold"><strong>Fett</strong></button>
            <button type="button" data-note-action="up" aria-label="Stichpunkt nach oben">↑</button>
            <button type="button" data-note-action="down" aria-label="Stichpunkt nach unten">↓</button>
            <button type="button" data-note-action="delete">Löschen</button>
          </div>
          <ul id="presenterNotes"></ul>
          <div class="presenter-actions">
            <button id="presenterPrev">Zurück</button>
            <button id="presenterNext">Weiter</button>
            <button id="presenterSave" ${this.editEnabled ? '' : 'hidden'}>Notizen speichern</button>
          </div>
        </aside>
        <section class="presenter-next"><div class="presenter-preview-stage"></div></section>
      </main>`);

    document.getElementById('presenterPrev').onclick = () => this.prev();
    document.getElementById('presenterNext').onclick = () => this.next();
    document.getElementById('presenterSave').onclick = () => this.savePresenterNotes();
    document.getElementById('presenterTitle').contentEditable = this.editEnabled ? 'true' : 'false';
    document.getElementById('presenterNotes').addEventListener('focusin', event => {
      const note = event.target.closest('li');
      if (note) this.setActiveNote(note);
    });
    document.querySelector('.presenter-note-toolbar')?.addEventListener('pointerdown', event => {
      if (event.target.closest('button')) event.preventDefault();
    });
    document.querySelector('.presenter-note-toolbar')?.addEventListener('click', event => {
      const action = event.target.closest('[data-note-action]')?.dataset.noteAction;
      if (action) this.handleNoteAction(action);
    });
    setInterval(() => this.renderTime(), 1000);
    this.renderPresenter();
    this.scalePresenter();
  }

  sanitizeNoteHtml(value) {
    const template = document.createElement('template');
    template.innerHTML = String(value ?? '');
    for (const element of [...template.content.querySelectorAll('*')]) {
      if (element.tagName === 'B') {
        const strong = document.createElement('strong');
        strong.innerHTML = element.innerHTML;
        element.replaceWith(strong);
      } else if (!['STRONG', 'BR'].includes(element.tagName)) {
        element.replaceWith(...element.childNodes);
      } else {
        for (const attribute of [...element.attributes]) element.removeAttribute(attribute.name);
      }
    }
    return template.innerHTML;
  }

  createNote(html = '', focus = true) {
    const note = document.createElement('li');
    note.innerHTML = this.sanitizeNoteHtml(html);
    note.contentEditable = this.editEnabled ? 'true' : 'false';
    document.getElementById('presenterNotes').appendChild(note);
    if (focus) {
      this.setActiveNote(note);
      note.focus();
    }
    return note;
  }

  setActiveNote(note) {
    this.activeNote = note;
    document.querySelectorAll('#presenterNotes li').forEach(element => {
      element.classList.toggle('selected-note', element === note);
    });
  }

  handleNoteAction(action) {
    if (!this.editEnabled) return;
    if (action === 'add') {
      this.createNote('Neuer Stichpunkt');
    } else if (action === 'bold') {
      if (this.activeNote) {
        const selection = getSelection();
        const selectionIsInside = selection?.rangeCount
          && this.activeNote.contains(selection.anchorNode)
          && this.activeNote.contains(selection.focusNode);
        if (!selectionIsInside) this.activeNote.focus();
        document.execCommand('bold', false);
      }
    } else if (action === 'delete' && this.activeNote) {
      const next = this.activeNote.nextElementSibling || this.activeNote.previousElementSibling;
      this.activeNote.remove();
      this.activeNote = null;
      if (next) this.setActiveNote(next);
    } else if (action === 'up' && this.activeNote?.previousElementSibling) {
      this.activeNote.parentElement.insertBefore(this.activeNote, this.activeNote.previousElementSibling);
    } else if (action === 'down' && this.activeNote?.nextElementSibling) {
      this.activeNote.parentElement.insertBefore(this.activeNote.nextElementSibling, this.activeNote);
    }
  }

  capturePresenterNotes() {
    if (!this.isPresenter || !this.editEnabled || !document.getElementById('presenterNotes')) return;
    const entry = (this.data.notes || [])[this.index] || { title: 'Notizen', bullets: [] };
    entry.title = document.getElementById('presenterTitle').textContent.trim() || 'Notizen';
    entry.bullets = [...document.querySelectorAll('#presenterNotes li')]
      .map(note => this.sanitizeNoteHtml(note.innerHTML.trim()))
      .filter(Boolean);
    this.data.notes ||= [];
    this.data.notes[this.index] = entry;
  }

  cloneSlide(index, target) {
    target.innerHTML = '';
    const source = this.slides[index];
    if (!source) return;
    const clone = source.cloneNode(true);
    clone.classList.add('active', 'visible');
    clone.style.position = 'absolute';
    target.appendChild(clone);
  }

  scalePresenter() {
    if (!this.isPresenter) return;
    document.querySelectorAll('.presenter-current,.presenter-next').forEach(box => {
      const stage = box.querySelector('.presenter-preview-stage');
      if (!stage) return;
      const factor = Math.min(box.clientWidth / 1920, box.clientHeight / 1080);
      stage.style.transform = `translate(${(box.clientWidth - 1920 * factor) / 2}px,${(box.clientHeight - 1080 * factor) / 2}px) scale(${factor})`;
    });
  }

  renderTime() {
    const element = document.getElementById('presenterTime');
    if (!element) return;
    const elapsed = Math.floor((Date.now() - this.started) / 1000);
    element.textContent = `${String(Math.floor(elapsed / 60)).padStart(2, '0')}:${String(elapsed % 60).padStart(2, '0')}`;
  }

  renderPresenter() {
    if (!this.isPresenter || !document.querySelector('.presenter-shell')) return;
    this.cloneSlide(this.index, document.querySelector('.presenter-current .presenter-preview-stage'));
    this.cloneSlide(this.index + 1, document.querySelector('.presenter-next .presenter-preview-stage'));
    document.getElementById('presenterCount').textContent = `${this.index + 1} / ${this.slides.length}`;

    const entry = (this.data.notes || [])[this.index] || { title: 'Notizen', bullets: [] };
    const title = document.getElementById('presenterTitle');
    title.textContent = entry.title || 'Notizen';
    title.contentEditable = this.editEnabled ? 'true' : 'false';

    const list = document.getElementById('presenterNotes');
    list.innerHTML = '';
    this.activeNote = null;
    const fragmentStep = this.fragments.get(this.index) || 0;
    (entry.bullets || []).forEach((bullet, bulletIndex) => {
      const note = this.createNote(this.sanitizeNoteHtml(bullet), false);
      if (/^KLICK:/i.test(note.textContent) && Math.max(0, fragmentStep - 1) === bulletIndex) {
        note.classList.add('current-step');
      }
    });
    if (list.firstElementChild) this.setActiveNote(list.firstElementChild);
    this.scalePresenter();
    this.renderTime();
  }

  async savePresenterNotes() {
    if (!this.editEnabled) return;
    this.capturePresenterNotes();
    const response = await fetch('/api/notes', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ notes: this.data.notes }),
    });
    if (!response.ok) throw new Error(await response.text());
  }
}

addEventListener('DOMContentLoaded', () => {
  window.blankDeck = new BlankDeckRuntime();
});
