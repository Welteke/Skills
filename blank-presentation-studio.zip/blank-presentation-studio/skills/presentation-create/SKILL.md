---
name: presentation-create
description: Create a BlankPresentationStudio HTML deck from notes, with explicit style selection, storyboard, speaker notes, and Chromium QA.
---

# Create presentation

Resolve the plugin root containing `.codex-plugin/plugin.json`. Read `../../references/content-policy.md`, `../../references/presentation-schema.md`, and `../../references/style-workflow.md`.

1. Preserve the raw input. Correct language only in authored content; do not invent facts.
2. Establish the deck style using the style workflow. Honor supplied preferences and references. When missing, ask for them; if none exist or the user wants suggestions, offer two or three concrete directions.
3. Unless the user asks to build directly, present the selected style and a storyboard with each slide's purpose, groups, layout direction and useful visual support. Wait for approval. Do not ask again for an already approved choice.
4. Author deck-local HTML/CSS for the content. There are no gallery templates or fixed branded components. Include concise speaker notes covering assigned details, with `KLICK: ...` for fragment steps.
5. Prepare a spec with `title`, `slug`, `language`, `input`, `storyboard`, `sources`, `styleDirection`, `theme`, optional deck-wide `css`, and `slides[]` as documented in the schema. Keep it under the target's `metadata/`; supplied assets belong under `assets/`.
6. Run `node "<studio-root>/scripts/build-deck.mjs" --project <target> --spec <spec>`. Never overwrite an existing deck.
7. Run `presentation-qa`, inspect screenshots, and fix blocking failures.

Keep every artifact inside the presentation folder. Default support files and exports to `metadata/`.
