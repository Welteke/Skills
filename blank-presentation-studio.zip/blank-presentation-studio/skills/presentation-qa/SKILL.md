---
name: presentation-qa
description: Validate a BlankPresentationStudio deck in Chromium for overflow, spacing, unexpected collisions, text contrast and readability, broken assets, navigation, presenter synchronization, slide numbering, UTF-8/mojibake, and PDF readiness. Use before completion and exports.
---

# Validate presentation

`<studio-root>` is the plugin directory containing `.codex-plugin/plugin.json` (three directory levels above this `SKILL.md`); resolve it before running commands.

Read and apply `../../references/qa-policy.md`. Run `node "<studio-root>/scripts/qa-deck.mjs" --project <project>`. Inspect every screenshot under `metadata/screenshots/`, not only numeric results. Fix and rerun until the automated result succeeds and the required visual checks pass. Test browsers other than Chromium only for a concrete reported concern.
