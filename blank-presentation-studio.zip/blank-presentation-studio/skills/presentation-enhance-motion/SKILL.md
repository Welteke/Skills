---
name: presentation-enhance-motion
description: Animate slide content and transitions in an existing BlankPresentationStudio deck, adapting slide design where useful for subtle, dynamic, or cinematic motion. Use when the user asks to make a deck fancy, cooler, more modern, animated, or more dynamic.
---

# Enhance motion

Use the intensity already chosen by the user. If none was chosen, ask for exactly one intensity before changing files:

- `subtle`: restrained element reveals, short diagram builds, and gentle emphasis.
- `dynamic`: coordinated element sequences, growing charts, moving highlights, and targeted morphs.
- `cinematic`: staged compositions, stronger spatial movement, and expressive section transitions.

## Animate the content

Read the current HTML, deck-local styles and runtime, `metadata/storyboard.md`, and `metadata/presentation.json`. Identify what the audience should notice first, which relationships should develop over time, and what should remain visible for reference.

A general motion pass must include meaningful animation of actual content within suitable slides. Changing only slide transitions, or applying the same entrance effect to every slide, is insufficient. Respect an explicit request for transitions only. Choose effects from the slide's message rather than from a fixed effect quota; intentionally quiet slides may remain static.

Examples to adapt, not a checklist:

- Build a process by introducing its stages and drawing their connecting paths in order.
- Grow chart bars or trace a trend, then reveal the annotation that explains the result. Preserve accurate values and readable labels.
- Introduce a comparison, move emphasis between its sides, and reveal the conclusion.
- Move or regroup objects to explain a change of structure, retaining enough context to follow their identity.
- Coordinate a headline, visual, and supporting details into a short sequence instead of moving the entire slide as one block.

Use automatic sequences for short entrances and presenter-controlled steps for explanations that need speaking time. Intensity controls movement and staging, not whether content animation exists. Avoid decorative loops or long waits that compete with reading.

## Adapt the slide design

You may change deck-local layout, grouping, spacing, scale, layering, and visual components when that makes the animation or explanation clearer. Split a static block into separately animated elements, rearrange a process into a buildable diagram, or reshape a composition around successive emphasis. These supporting design changes are part of the motion pass and do not require separate design approval.

Preserve facts, wording intent, chosen visual identity, and any explicit user constraints. Maintain a coherent, readable final composition. Keep changes local to the deck; the plugin runtime is outside this pass. Record material layout changes and the intended sequence in the storyboard.

## Implement and verify

Use the deck's existing animation and fragment mechanisms where suitable; add deck-local CSS or JavaScript when the intended behavior needs more control. Inspect the actual runtime before extending it. Keep navigation, fragment state, and animation state synchronized. Stop inactive-slide animations and make revisiting slides or stepping backward produce predictable states.

Keep click fragments synchronized with `KLICK:` notes and ensure the next full slide remains visible in Presenter preview. PDF mode must show a readable static result without relying on animation completion. Ensure custom animated elements are included, not just standard fragments.

Update `index.html`, affected deck-local assets, `metadata/storyboard.md`, and `metadata/presentation.json` together; record the motion level using the deck's existing metadata conventions. Run `presentation-qa`. Also watch the changed slides in Chromium from entry through their intermediate steps to completion: static screenshots alone cannot verify motion. Check click timing, backward navigation, revisits, Presenter preview, and PDF mode. Fix transient collisions, unreadable moving text, stranded hidden content, and sequences that obstruct the explanation.

In the completion report, describe the content animations and any material design changes, alongside the selected intensity and validation results.
