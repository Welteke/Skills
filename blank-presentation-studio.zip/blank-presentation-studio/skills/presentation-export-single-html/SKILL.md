---
name: presentation-export-single-html
description: Export a finished, validated BlankPresentationStudio deck as one self-contained HTML file with local images, fonts, media, styles, and scripts embedded. Use only when the user explicitly asks for a single-file HTML, standalone HTML, self-contained HTML, or an HTML handoff without Studio editing and Presenter mode.
---

# Export single HTML

`<studio-root>` is the plugin directory containing `.codex-plugin/plugin.json` (three directory levels above this `SKILL.md`); resolve it before running commands.

1. Require a finished Studio presentation with `index.html` and `metadata/presentation.json`. Run `presentation-qa` first and stop on failures.
2. Run `node "<studio-root>/scripts/export-single-html.mjs" --project <project>`. The default output is `metadata/single-html/<project>.html`. Use `--output <relative-in-project.html>` only for another destination inside the presentation folder.
3. Do not overwrite an existing export unless the user explicitly requests replacement; then add `--force`.
4. Deliver only the generated HTML file. It must embed all local images, fonts, audio, video, CSS, and JavaScript as data or inline content. Treat an external, absolute, missing, or out-of-project resource as a blocking error rather than producing a partially portable file.
5. Verify the output in Chromium from its local `file:` URL. Confirm that scaling, keyboard navigation, mouse-wheel navigation, touch navigation, links, animations, and fragments still work.
6. Confirm that `E`, `P`, and `?presenter=1` do not activate Studio features. The export must contain no editing toolbar, editable fields, Presenter UI, synchronization channel, speaker notes, or deck metadata.

Keep the editable source deck unchanged. This workflow is optional and must never run as part of ordinary creation, update, QA, PDF, or handout work unless the user explicitly requests the single-file HTML output.
