---
name: presentation-create-handout
description: Create a responsive HTML handout from an already finished BlankPresentationStudio deck and its final visual language. Use when the user asks for a handout, reader version, presentation summary, or complete HTML document derived from an existing deck rather than another 16:9 presentation.
---

# Create presentation handout

`<studio-root>` is the plugin directory containing `.codex-plugin/plugin.json` (three directory levels above this `SKILL.md`); resolve it before running commands.

1. Require a finished Studio presentation with `index.html` and `metadata/presentation.json`. Inspect the rendered deck, its final slide layouts, `metadata/input.md`, `metadata/storyboard.md`, presenter notes, and used assets. Do not start from raw notes when the finished deck is available.
2. Before authoring, ask exactly one scope question unless the user already chose: **Kurzfassung** (core messages and decisions) or **Vollständig** (all presentation content in reading order). Do not combine this with questions about tabs, layout, or styling.
3. Treat the deck's final visual design as the reference. Translate its colors, typography, spacing, card language, image treatment, and graphic motifs into a vertically flowing web page. Do not copy the fixed slide stage, navigation, presenter UI, page numbers, or fragment behavior.
4. Build a reading hierarchy rather than a slide transcript. Merge repeated framing and transitions. Preserve facts, numbers, claims, links, and intent; do not invent content. In `full` mode, map every source slide to at least one chapter through `sourceSlides`. In `short` mode, retain only the core story and state no unsupported conclusions.
5. Use tabs only when at least three genuine chapters benefit from quick switching. Otherwise use one continuous page. The build script defaults to tabs at three chapters; set `tabs: false` when continuous reading is stronger. Never create tabs merely to imitate slide navigation.
6. Create a handout spec under the presentation's `metadata/` folder. Use `mode: "short"` or `mode: "full"`, a `chapters` array, and optional `theme`, `fonts`, `brandLabel`, `themeCss`, `tabs`, `description`, `eyebrow`, and `footer` fields. Each chapter requires `title`, `sourceSlides`, and `blocks`.

Supported block forms:

```json
{"type":"text","heading":"Einordnung","paragraphs":["Absatz"]}
{"type":"bullets","heading":"Kernpunkte","items":["Punkt"]}
{"type":"cards","heading":"Handlungsfelder","items":[{"title":"Titel","text":"Text"}]}
{"type":"facts","heading":"Kennzahlen","items":[{"label":"Label","value":"42 %","text":"Einordnung"}]}
{"type":"quote","text":"Zitat","attribution":"Quelle"}
{"type":"media","heading":"Optional","src":"bild.png","caption":"Optional"}
```

Colors and font stacks default to the source deck theme. Use `themeCss` to translate its specific shapes and composition. Never add a Studio wordmark or logo. `brandLabel` is optional and only for user-requested branding.

7. Reference media by its path below the presentation's `assets/` folder. Use `themeCss` only for deliberate deck-specific visual translation and keep the page responsive. Do not introduce external CDNs, absolute local paths, or remote dependencies.
8. Run `node "<studio-root>/scripts/build-handout.mjs" --project <project> --spec <spec>`. The default output is `metadata/handout/index.html` with `handout.json` and screenshots beside it. The builder refuses to replace an existing handout; use `--force` only when the user explicitly requests replacement or revision.
9. Run `node "<studio-root>/scripts/qa-handout.mjs" --project <project>`. Inspect both `metadata/handout/screenshots/handout-desktop.png` and `handout-mobile.png`. Fix horizontal overflow, broken assets, unreadable contrast, weak hierarchy, tab problems, and any remaining fixed-slide geometry before delivery.

Keep the handout inside the presentation project. The result is an HTML page, not a deck: it must work at arbitrary page height, adapt to mobile width, print in normal document flow, and remain understandable without slide controls or speaker notes.
