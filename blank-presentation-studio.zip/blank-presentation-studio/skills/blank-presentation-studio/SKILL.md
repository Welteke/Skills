---
name: blank-presentation-studio
description: Create and revise HTML presentations with BlankPresentationStudio using a chosen visual style, without a brand preset or slide gallery. Route animation, QA, handout, PDF and self-contained HTML requests for these decks.
---

# BlankPresentationStudio

Use a fixed 1920×1080 stage, UTF-8, local assets and deck-local visual design. Do not inherit ATE colors, logos, fonts or layout requirements. User-supplied branding is welcome when requested.

Resolve `<studio-root>` as the plugin folder containing `.codex-plugin/plugin.json`, then run scripts with absolute paths. Read `../../references/content-policy.md` and `../../references/presentation-schema.md` for content work. Use `../../references/style-workflow.md` before choosing or changing visual direction.

- New deck: `presentation-create`.
- Existing BlankPresentationStudio deck: `presentation-update`.
- Content animation or transitions: `presentation-enhance-motion`.
- Chromium validation before delivery and exports: `presentation-qa`.
- Responsive reader document from a finished deck: `presentation-create-handout`.
- Slide-only PDF: `presentation-export-pdf`.
- One self-contained HTML file: `presentation-export-single-html`.

Retain local editing, Presenter mode, speaker notes, click fragments, navigation and scaling in the editable project. The portable single HTML keeps navigation and motion while removing editing, Presenter mode and notes.

Do not add gallery management, global styling, ATE migration, snapshot ZIPs, ZIP publishing, web hosting or password protection to this plugin. It has no runtime dependency on another Studio installation. Keep generated files inside the presentation folder, defaulting support files and exports to `metadata/`.
