---
name: presentation-update
description: Revise an existing BlankPresentationStudio HTML deck, including slide text, order, layouts, assets, notes, diagrams, and local design tokens. Use for decks identified as BlankPresentationStudio in metadata/presentation.json.
---

# Update presentation

Confirm `metadata/presentation.json` identifies a BlankPresentationStudio deck. Read `../../references/content-policy.md`, the raw input, storyboard, presentation metadata, and current HTML before editing. Preserve facts and intent; correct language and encoding. Treat all style changes as deck-local. For a new style direction, apply `../../references/style-workflow.md`. Keep theme metadata and rendered CSS consistent.


Update `index.html`, `metadata/storyboard.md`, and `metadata/presentation.json` together. Append new source input with a date to `metadata/input.md`; never rewrite the original input. Do not create automatic backups. After structural or visual changes, run `presentation-qa` and fix blocking issues.


Keep every generated artifact inside the presentation folder, with unspecified support files under `metadata/`.
