---
name: presentation-export-pdf
description: Export a validated BlankPresentationStudio deck as a slide-only PDF rendered at 1920×1080 with all fragments visible. Use when the user requests PDF output from a Studio presentation.
---

# Export PDF

`<studio-root>` is the plugin directory containing `.codex-plugin/plugin.json` (three directory levels above this `SKILL.md`); resolve it before running commands.

Run `presentation-qa` first and stop on failures. Then run `node "<studio-root>/scripts/export-pdf.mjs" --project <project> [--output <relative-in-project.pdf>]`. Default to `metadata/pdf/<project>.pdf`. Reject every output path outside the presentation folder. Export one 16:9 page per slide from the 1920×1080 stage, exclude Presenter UI and notes, and show every animation fragment in its final state. Preserve vector content and keep embedded raster images sharp at the intended display size. If file size is a concern, adjust compression without making raster content visibly soft.
