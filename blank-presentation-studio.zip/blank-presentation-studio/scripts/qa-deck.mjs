import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {parseArgs,readJson} from './lib.mjs';
import {launchChromium} from './dependencies.mjs';

const args=parseArgs(process.argv);
if(!args.project)throw new Error('Aufruf: node qa-deck.mjs --project <ordner>');
const project=path.resolve(args.project);
const htmlPath=path.join(project,'index.html');
const html=await fs.readFile(htmlPath,'utf8');
const failures=[];
for(const bad of ['Ã¤','Ã¶','Ã¼','ÃŸ','ÃƒÂ¤','ÃƒÂ¶','ÃƒÂ¼','ÃƒÅ¸','\uFFFD'])if(html.includes(bad))failures.push(`Kodierungsfehler gefunden: ${bad}`);
if(/(?:src|href)=["']file:/i.test(html))failures.push('Absoluter file:-Pfad gefunden');

const browser=await launchChromium({headless:true});
const page=await browser.newPage({viewport:{width:1920,height:1080}});
page.on('pageerror',error=>failures.push(`JavaScript: ${error.message}`));
page.on('requestfailed',request=>failures.push(`Ressource fehlt: ${request.url()}`));
await page.goto(pathToFileURL(htmlPath).href);
await page.evaluate(()=>document.fonts.ready);
if(await page.locator('.deck-controls').count())failures.push('Veraltete Slide-Auswahl ist noch vorhanden');
await page.evaluate(()=>document.body.classList.add('pdf-mode'));
const slideCount=await page.locator('.slide').count();
await fs.mkdir(path.join(project,'metadata','screenshots'),{recursive:true});
const meta=await readJson(path.join(project,'metadata','presentation.json'));

for(let index=0;index<slideCount;index++){
  await page.evaluate(slide=>window.blankDeck.show(slide,false),index);
  const slide=page.locator('.slide').nth(index);
  const numbering = await slide.locator('.page-no').textContent().catch(()=>null);
  if(numbering?.trim() !== `${String(index+1).padStart(2,'0')} / ${String(slideCount).padStart(2,'0')}`) failures.push(`Folie ${index+1}: Foliennummer fehlt oder ist falsch`);
  const pairs=(meta.allowedOverlaps||[]).find(item=>item.slide===index+1)?.pairs||[];
  const issues=await slide.evaluate((root,allowed)=>{
    const out=[];
    for(const image of root.querySelectorAll('img')) if(!image.complete || !image.naturalWidth) out.push(`Bild fehlt: ${image.getAttribute('src')}`);
    const rootRect=root.getBoundingClientRect();
    const textSelector='h1,h2,h3,h4,p,li,article,a,span,small,button,[data-edit-id]';

    for(const element of root.querySelectorAll('h1,h2,h3,p,li,article,a,[data-edit-id]')){
      const rect=element.getBoundingClientRect();
      if(rect.left<rootRect.left-1||rect.top<rootRect.top-1||rect.right>rootRect.right+1||rect.bottom>rootRect.bottom+1)out.push(`Außerhalb: ${element.tagName}.${element.className}`);
      const panel=element.closest('article');
      if(panel&&panel!==element){
        const panelRect=panel.getBoundingClientRect();
        if(rect.left<panelRect.left-2||rect.top<panelRect.top-2||rect.right>panelRect.right+2||rect.bottom>panelRect.bottom+2)out.push(`Text verlässt Panel: ${element.tagName}.${element.className}`);
      }
    }

    const isAllowed=(a,b)=>allowed.some(([x,y])=>(a.matches(x)&&b.matches(y))||(a.matches(y)&&b.matches(x)));
    const boxes=[...root.querySelectorAll('article,[data-qa-box]')]
      .filter(element=>getComputedStyle(element).visibility!=='hidden')
      .map(element=>({element,rect:element.getBoundingClientRect()}));
    for(let a=0;a<boxes.length;a++)for(let b=a+1;b<boxes.length;b++){
      const x=boxes[a].rect,y=boxes[b].rect;
      const hit=x.left<y.right&&x.right>y.left&&x.top<y.bottom&&x.bottom>y.top;
      if(hit&&!boxes[a].element.contains(boxes[b].element)&&!boxes[b].element.contains(boxes[a].element)&&!isAllowed(boxes[a].element,boxes[b].element))out.push(`Kollision: ${boxes[a].element.className} / ${boxes[b].element.className}`);
    }

    const parseColor=value=>{
      const match=value.match(/rgba?\(([^)]+)\)/);
      if(!match)return null;
      const parts=match[1].split(/[ ,/]+/).filter(Boolean).map(Number);
      return [parts[0],parts[1],parts[2],parts.length>3?parts[3]:1];
    };
    const blend=(top,bottom)=>{
      const alpha=top[3]+bottom[3]*(1-top[3]);
      if(!alpha)return [255,255,255,0];
      return [0,1,2].map(channel=>(top[channel]*top[3]+bottom[channel]*bottom[3]*(1-top[3]))/alpha).concat(alpha);
    };
    const luminance=color=>{
      const channels=color.slice(0,3).map(value=>{const normalized=value/255;return normalized<=.04045?normalized/12.92:Math.pow((normalized+.055)/1.055,2.4)});
      return .2126*channels[0]+.7152*channels[1]+.0722*channels[2];
    };
    const contrast=(a,b)=>{const first=luminance(a),second=luminance(b);return (Math.max(first,second)+.05)/(Math.min(first,second)+.05)};
    const effectiveBackground=element=>{
      const layers=[];
      let current=element,complex=false;
      while(current){
        const style=getComputedStyle(current);
        if(style.backgroundImage!=='none')complex=true;
        const color=parseColor(style.backgroundColor);
        if(color&&color[3]>0)layers.push(color);
        current=current.parentElement;
      }
      const rect=element.getBoundingClientRect();
      const centerX=Math.max(0,Math.min(innerWidth-1,rect.left+rect.width/2));
      const centerY=Math.max(0,Math.min(innerHeight-1,rect.top+rect.height/2));
      for(const behind of document.elementsFromPoint(centerX,centerY)){
        if(behind===element||behind.contains(element)||element.contains(behind))continue;
        if(getComputedStyle(behind).backgroundImage!=='none'){complex=true;break;}
      }
      let result=[255,255,255,1];
      for(const layer of layers.reverse())result=blend(layer,result);
      return {color:result,complex};
    };
    const label=element=>`${element.tagName}.${String(element.className||'').trim().replace(/\s+/g,'.')}`;
    const audited=new Set();
    for(const element of root.querySelectorAll(textSelector)){
      if(element.closest('[data-qa-contrast-ignore]'))continue;
      if(![...element.childNodes].some(node=>node.nodeType===Node.TEXT_NODE&&node.textContent.trim()))continue;
      const style=getComputedStyle(element),rect=element.getBoundingClientRect();
      if(style.visibility==='hidden'||style.display==='none'||Number(style.opacity)===0||rect.width<1||rect.height<1)continue;
      const foreground=parseColor(style.color),background=effectiveBackground(element);
      if(!foreground||background.complex)continue;
      const effectiveForeground=blend(foreground,background.color);
      const ratio=contrast(effectiveForeground,background.color);
      const key=label(element);
      if(ratio<3&&!audited.has(key)){
        audited.add(key);
        const sample=(element.textContent||'').trim().replace(/\s+/g,' ').slice(0,48);
        out.push(`Niedriger Textkontrast (${ratio.toFixed(2)}:1): ${key} „${sample}“`);
      }
    }
    return out;
  },pairs);
  for(const issue of issues)failures.push(`Folie ${index+1}: ${issue}`);
  await slide.screenshot({path:path.join(project,'metadata','screenshots',`slide-${String(index+1).padStart(2,'0')}.png`)});
}

await browser.close();
const result={ok:failures.length===0,slides:slideCount,failures};
await fs.writeFile(path.join(project,'metadata','qa-results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
if(failures.length)process.exitCode=1;
