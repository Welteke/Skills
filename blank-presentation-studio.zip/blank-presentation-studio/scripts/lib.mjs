import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
export const pluginRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export async function readJson(file){return JSON.parse(await fs.readFile(file,'utf8'))}
export async function inlineIcons(html){const names=[...new Set([...html.matchAll(/data-icon="([^"]+)"/g)].map(m=>m[1]))];for(const name of names){if(!/^[a-z0-9-]+$/.test(name))throw new Error(`Ungültiger Icon-Name: ${name}`);const file=path.join(pluginRoot,'assets','icons','tabler',`${name}.svg`);let svg;try{svg=await fs.readFile(file,'utf8')}catch{throw new Error(`Tabler-Icon fehlt: ${name}`)}html=html.replaceAll(`<div data-icon="${name}"></div>`,`<div class="inline-icon" aria-hidden="true">${svg}</div>`)}return html}
export function parseArgs(argv){const out={};for(let i=2;i<argv.length;i++){if(argv[i].startsWith('--')){const key=argv[i].slice(2);out[key]=argv[i+1]&&!argv[i+1].startsWith('--')?argv[++i]:true}}return out}
export function resolveProjectPath(project,value,fallback){const root=path.resolve(project);const target=path.resolve(root,value||fallback);const relative=path.relative(root,target);if(relative.startsWith('..')||path.isAbsolute(relative))throw new Error(`Zielpfad liegt außerhalb des Präsentationsordners: ${target}`);return target}
