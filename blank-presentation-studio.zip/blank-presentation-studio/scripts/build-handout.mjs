import fs from 'node:fs/promises';
import path from 'node:path';
import {escapeHtml, parseArgs, readJson, resolveProjectPath} from './lib.mjs';

const args = parseArgs(process.argv);
if (!args.project || !args.spec) {
  throw new Error('Aufruf: node build-handout.mjs --project <ordner> --spec <handout-spec.json>');
}

const project = path.resolve(args.project);
const spec = await readJson(path.resolve(args.spec));
const presentation = await readJson(path.join(project, 'metadata', 'presentation.json'));
const output = resolveProjectPath(project, args.output, 'metadata/handout');
try {
  await fs.access(path.join(output, 'index.html'));
  if (!args.force) throw new Error(`Handout existiert bereits: ${output}. Zum Ersetzen --force verwenden.`);
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
}
const mode = spec.mode === 'full' ? 'full' : spec.mode === 'short' ? 'short' : null;
if (!mode) throw new Error('handout-spec: mode muss "short" oder "full" sein.');
if (!Array.isArray(spec.chapters) || !spec.chapters.length) {
  throw new Error('handout-spec: chapters muss mindestens ein Kapitel enthalten.');
}

const sourceSlideCount = presentation.notes?.length || presentation.templates?.length || 0;
const referencedSlides = new Set(spec.chapters.flatMap(chapter => chapter.sourceSlides || []).map(Number));
const invalidSlides = [...referencedSlides].filter(slide => !Number.isInteger(slide) || slide < 1 || (sourceSlideCount && slide > sourceSlideCount));
if (invalidSlides.length) throw new Error(`Ungültige Folienzuordnung: ${invalidSlides.join(', ')}`);
if (mode === 'full' && sourceSlideCount) {
  const missing = Array.from({length: sourceSlideCount}, (_, index) => index + 1)
    .filter(slide => !referencedSlides.has(slide));
  if (missing.length) {
    throw new Error(`Vollständiges Handout: Folien ohne Zuordnung: ${missing.join(', ')}`);
  }
}

const {fonts: deckFonts, ...deckColors} = presentation.theme || {};
const theme = {...deckColors, ...(spec.theme || {})};
for (const key of ['accent','accent2','ink','muted','background','surface']) if (!theme[key]) throw new Error('Deck-Stil fehlt: ' + key);
const fonts = {...deckFonts, ...(spec.fonts || {})};
for (const key of ['display','body','mono']) if (!/^[a-zA-Z0-9 ,"'-]+$/.test(fonts[key] || '')) throw new Error('Ungültiger Font-Stack: ' + key);
for (const key of Object.keys(theme)) {
  if (!/^#[0-9a-f]{6}$/i.test(theme[key])) throw new Error(`Ungültige Theme-Farbe: ${key}`);
}

const renderParagraphs = paragraphs => (paragraphs || [])
  .map(paragraph => `<p>${escapeHtml(paragraph)}</p>`).join('');
const renderItems = items => (items || [])
  .map(item => `<li>${escapeHtml(item)}</li>`).join('');

function renderBlock(block) {
  const heading = block.heading ? `<h3>${escapeHtml(block.heading)}</h3>` : '';
  switch (block.type) {
    case 'text':
      return `<section class="content-block prose">${heading}${renderParagraphs(block.paragraphs)}</section>`;
    case 'bullets':
      return `<section class="content-block bullets">${heading}<ul>${renderItems(block.items)}</ul></section>`;
    case 'cards':
      return `<section class="content-block">${heading}<div class="card-grid">${(block.items || []).map(item => (
        `<article class="card"><h4>${escapeHtml(item.title)}</h4><p>${escapeHtml(item.text)}</p></article>`
      )).join('')}</div></section>`;
    case 'facts':
      return `<section class="content-block">${heading}<dl class="facts">${(block.items || []).map(item => (
        `<div><dt>${escapeHtml(item.label)}</dt><dd><strong>${escapeHtml(item.value)}</strong>${item.text ? `<span>${escapeHtml(item.text)}</span>` : ''}</dd></div>`
      )).join('')}</dl></section>`;
    case 'quote':
      return `<blockquote><p>${escapeHtml(block.text)}</p>${block.attribution ? `<footer>${escapeHtml(block.attribution)}</footer>` : ''}</blockquote>`;
    case 'media': {
      const asset = String(block.src || '').replaceAll('\\', '/').replace(/^\.\//, '');
      if (!asset || asset.includes('..') || /^(?:[a-z]+:|\/)/i.test(asset)) {
        throw new Error(`Ungültiger Medienpfad im Handout: ${block.src || '(leer)'}`);
      }
      return `<figure>${heading}<img src="../../assets/${escapeHtml(asset)}" alt="${escapeHtml(block.alt || '')}">${block.caption ? `<figcaption>${escapeHtml(block.caption)}</figcaption>` : ''}</figure>`;
    }
    default:
      throw new Error(`Unbekannter Handout-Blocktyp: ${block.type}`);
  }
}

const useTabs = spec.tabs === true || (spec.tabs !== false && spec.chapters.length >= 3);
const chapterMarkup = spec.chapters.map((chapter, index) => {
  const id = `kapitel-${index + 1}`;
  const eyebrow = chapter.eyebrow ? `<p class="eyebrow">${escapeHtml(chapter.eyebrow)}</p>` : '';
  const summary = chapter.summary ? `<p class="chapter-summary">${escapeHtml(chapter.summary)}</p>` : '';
  return `<section class="chapter" id="${id}"${useTabs ? ` role="tabpanel" aria-labelledby="tab-${id}"${index ? ' hidden' : ''}` : ''}>${eyebrow}<h2>${escapeHtml(chapter.title)}</h2>${summary}${(chapter.blocks || []).map(renderBlock).join('')}</section>`;
}).join('');
const tabs = useTabs ? `<nav class="chapter-tabs" role="tablist" aria-label="Kapitel">${spec.chapters.map((chapter, index) => {
  const id = `kapitel-${index + 1}`;
  return `<button id="tab-${id}" role="tab" aria-controls="${id}" aria-selected="${index === 0}" tabindex="${index === 0 ? 0 : -1}">${escapeHtml(chapter.tabLabel || chapter.title)}</button>`;
}).join('')}</nav>` : '';

const logo = spec.brandLabel ? `<span class="brand-wordmark">${escapeHtml(spec.brandLabel)}</span>` : '';
const description = spec.description || (mode === 'short' ? 'Kompakte Zusammenfassung der Präsentation' : 'Vollständiges Handout zur Präsentation');
const customCss = String(spec.themeCss || '');
const requiredAssets = [
  'sora-700.woff2',
  'ibm-plex-sans-400.woff2',
  'ibm-plex-sans-600.woff2',
  ...spec.chapters.flatMap(chapter => (chapter.blocks || []))
    .filter(block => block.type === 'media')
    .map(block => String(block.src || '').replaceAll('\\', '/').replace(/^\.\//, ''))
];
for (const asset of new Set(requiredAssets)) {
  try {
    await fs.access(path.join(project, 'assets', asset));
  } catch {
    throw new Error(`Handout-Asset fehlt: assets/${asset}`);
  }
}

const html = `<!doctype html>
<html lang="${escapeHtml(presentation.language || 'de')}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="description" content="${escapeHtml(description)}">
  <title>${escapeHtml(spec.title || presentation.title)} · Handout</title>
  <style>
    @font-face{font-family:Sora;src:url('../../assets/sora-700.woff2')}@font-face{font-family:'IBM Plex Sans';src:url('../../assets/ibm-plex-sans-400.woff2')}@font-face{font-family:'IBM Plex Sans';src:url('../../assets/ibm-plex-sans-600.woff2');font-weight:600}
    :root{--accent:${theme.accent};--accent-2:${theme.accent2};--ink:${theme.ink};--muted:${theme.muted};--bg:${theme.background};--surface:${theme.surface};--display:${fonts.display};--body:${fonts.body};--mono:${fonts.mono};--radius:22px;--max:1160px}
    *{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--bg);color:var(--ink);font:18px/1.65 var(--body)}img{display:block;max-width:100%;height:auto}a,button{font:inherit}button:focus-visible,a:focus-visible{outline:3px solid var(--accent-2);outline-offset:3px}
    .site-header{background:var(--surface);border-bottom:1px solid color-mix(in srgb,var(--ink) 12%,transparent)}.header-inner,.hero-inner,.main-inner,.site-footer-inner{width:min(calc(100% - 40px),var(--max));margin:auto}.header-inner{min-height:76px;display:flex;align-items:center;justify-content:space-between;gap:24px}.brand-logo{width:88px}.brand-wordmark{font:700 26px var(--display);color:var(--accent)}.mode-label,.eyebrow{font-size:13px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--accent-2)}
    .hero{padding:clamp(64px,9vw,128px) 0;background:linear-gradient(135deg,var(--surface),color-mix(in srgb,var(--accent) 9%,var(--surface)))}.hero-inner{display:block}.hero h1{max-width:850px;margin:10px 0 22px;font:700 clamp(42px,7vw,82px)/1.02 var(--display);letter-spacing:-.045em}.hero p{max-width:720px;margin:0;color:var(--muted);font-size:clamp(19px,2vw,25px)}
    .main-inner{padding:56px 0 96px}.chapter-tabs{position:sticky;top:0;z-index:4;display:flex;gap:8px;overflow:auto;padding:12px;margin:0 0 44px;background:color-mix(in srgb,var(--bg) 92%,transparent);backdrop-filter:blur(12px);border-radius:16px}.chapter-tabs button{border:0;border-radius:12px;padding:11px 16px;background:transparent;color:var(--muted);white-space:nowrap;cursor:pointer}.chapter-tabs button[aria-selected=true]{background:var(--ink);color:var(--surface)}
    .chapter{margin:0 0 80px}.chapter[hidden]{display:none}.chapter h2{max-width:900px;margin:8px 0 18px;font:700 clamp(34px,5vw,58px)/1.08 var(--display);letter-spacing:-.035em}.chapter-summary{max-width:850px;margin:0 0 42px;color:var(--muted);font-size:22px}.content-block{margin:34px 0}.content-block h3,figure h3{margin:0 0 16px;font-family:var(--display);font-size:clamp(23px,3vw,31px);font-weight:700;line-height:1.2}.prose p{max-width:850px;margin:0 0 16px}.bullets ul{max-width:850px;padding-left:1.25em}.bullets li{margin:8px 0}.card-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,260px),1fr));gap:18px}.card{padding:26px;border:1px solid color-mix(in srgb,var(--ink) 12%,transparent);border-radius:var(--radius);background:var(--surface)}.card h4{margin:0 0 10px;font-family:var(--display);font-size:21px;font-weight:700;line-height:1.25}.card p{margin:0;color:var(--muted)}
    .facts{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,240px),1fr));gap:18px;margin:0}.facts div{padding:24px;border-top:4px solid var(--accent);background:var(--surface)}.facts dt{color:var(--muted);font-size:15px}.facts dd{margin:8px 0 0}.facts strong{display:block;font:700 30px var(--display)}.facts span{display:block;margin-top:8px}blockquote{margin:42px 0;padding:clamp(28px,5vw,54px);border-radius:var(--radius);background:var(--ink);color:var(--surface)}blockquote p{margin:0;font:700 clamp(27px,4vw,44px)/1.28 var(--display)}blockquote footer{margin-top:20px;color:color-mix(in srgb,var(--surface) 70%,transparent)}figure{margin:42px 0}figure img{width:100%;max-height:720px;object-fit:contain;border-radius:var(--radius);background:var(--surface)}figcaption{margin-top:10px;color:var(--muted);font-size:15px}
    .site-footer{padding:32px 0;background:var(--ink);color:var(--surface)}.site-footer-inner{display:flex;justify-content:space-between;gap:24px;flex-wrap:wrap}.site-footer p{margin:0}.site-footer .muted{color:color-mix(in srgb,var(--surface) 62%,transparent)}
    @media(max-width:760px){body{font-size:17px}.hero-inner{grid-template-columns:1fr}.chapter-tabs{margin-inline:-8px}.main-inner{padding-top:32px}.chapter{margin-bottom:56px}}
    @media print{body{background:#fff}.chapter-tabs{display:none}.chapter[hidden]{display:block!important}.chapter{break-inside:auto}.card,blockquote,figure,.facts div{break-inside:avoid}.site-header{position:static}}
    ${customCss}
  </style>
</head>
<body data-handout-mode="${mode}" data-source-slides="${sourceSlideCount}">
  <header class="site-header"><div class="header-inner">${logo}<span class="mode-label">${mode === 'short' ? 'Kurz-Handout' : 'Vollständiges Handout'}</span></div></header>
  <section class="hero"><div class="hero-inner"><div><p class="eyebrow">${escapeHtml(spec.eyebrow || 'Handout zur Präsentation')}</p><h1>${escapeHtml(spec.title || presentation.title)}</h1><p>${escapeHtml(description)}</p></div></div></section>
  <main class="main-inner">${tabs}${chapterMarkup}</main>
  <footer class="site-footer"><div class="site-footer-inner"><p>${escapeHtml(spec.footer || presentation.title)}</p><p class="muted">Erstellt aus ${sourceSlideCount} Präsentationsfolien</p></div></footer>
  ${useTabs ? `<script>const tabs=[...document.querySelectorAll('[role=tab]')];const panels=[...document.querySelectorAll('[role=tabpanel]')];function selectTab(tab){tabs.forEach((item,index)=>{const active=item===tab;item.setAttribute('aria-selected',active);item.tabIndex=active?0:-1;panels[index].hidden=!active});tab.focus()}tabs.forEach((tab,index)=>{tab.addEventListener('click',()=>selectTab(tab));tab.addEventListener('keydown',event=>{let next;if(event.key==='ArrowRight')next=(index+1)%tabs.length;if(event.key==='ArrowLeft')next=(index-1+tabs.length)%tabs.length;if(event.key==='Home')next=0;if(event.key==='End')next=tabs.length-1;if(next!==undefined){event.preventDefault();selectTab(tabs[next])}})});</script>` : ''}
</body>
</html>`;

await fs.mkdir(path.join(output, 'screenshots'), {recursive: true});
await fs.writeFile(path.join(output, 'index.html'), html, 'utf8');
const handoutData = {
  studioVersion: presentation.studioVersion,
  sourcePresentation: presentation.slug,
  sourceSlideCount,
  referencedSlides: [...referencedSlides].sort((a, b) => a - b),
  mode,
  tabs: useTabs,
  title: spec.title || presentation.title,
  chapters: spec.chapters.map(chapter => chapter.title)
};
await fs.writeFile(path.join(output, 'handout.json'), JSON.stringify(handoutData, null, 2) + '\n', 'utf8');
console.log(`Handout erstellt: ${path.join(output, 'index.html')} (${mode}, ${spec.chapters.length} Kapitel)`);

