import fs from 'node:fs/promises';
import path from 'node:path';
import {
  pluginRoot, readJson, inlineIcons,
  parseArgs, escapeHtml
} from './lib.mjs';

const args = parseArgs(process.argv);
if (!args.project || !args.spec) throw new Error('Aufruf: node build-deck.mjs --project <ordner> --spec <deck-spec.json>');
const project = path.resolve(args.project);
const specPath = path.resolve(args.spec);
const spec = await readJson(specPath);
if (!spec.title || !Array.isArray(spec.slides) || !spec.slides.length) {
  throw new Error('Deck-Spezifikation benötigt title und mindestens eine Folie in slides[].');
}


if (args.force) throw new Error('Neue Decks dürfen bestehende Projekte nicht überschreiben. Für Änderungen den Update-Workflow verwenden.');
if (!spec.styleDirection || typeof spec.styleDirection !== 'string') throw new Error('styleDirection muss den gewählten Stil beschreiben.');
const colorKeys = ['accent','accent2','ink','muted','background','surface'];
for (const key of colorKeys) if (!/^#[0-9a-f]{6}$/i.test(spec.theme?.[key] || '')) throw new Error('theme.' + key + ' muss eine sechsstellige Hex-Farbe sein.');
for (const key of ['display','body','mono']) if (!/^[a-zA-Z0-9 ,"'-]+$/.test(spec.theme?.fonts?.[key] || '')) throw new Error('theme.fonts.' + key + ' benötigt einen Font-Stack ohne CSS-Anweisungen.');
const themeCss = ':root{--accent:'+spec.theme.accent+';--accent-2:'+spec.theme.accent2+';--ink:'+spec.theme.ink+';--muted:'+spec.theme.muted+';--paper:'+spec.theme.background+';--surface:'+spec.theme.surface+';--display:'+spec.theme.fonts.display+';--body:'+spec.theme.fonts.body+';--mono:'+spec.theme.fonts.mono+'}';

function assetPath(root, asset) {
  const value = String(asset || '');
  const target = path.resolve(root, value);
  const relative = path.relative(root, target);
  if (!value || relative.startsWith('..') || path.isAbsolute(relative)) {
    throw new Error(`Ungültiger Asset-Pfad: ${value || '(leer)'}`);
  }
  return target;
}

async function filesBelow(directory) {
  const files = [];
  async function walk(current) {
    for (const entry of await fs.readdir(current, {withFileTypes: true})) {
      const target = path.join(current, entry.name);
      if (entry.isDirectory()) await walk(target);
      else if (entry.isFile()) files.push(target);
    }
  }
  await walk(directory);
  return files;
}

try {
  await fs.access(project);
  if (!args.force) {
    for (const marker of ['index.html', path.join('metadata', 'presentation.json')]) {
      try {
        await fs.access(path.join(project, marker));
        throw new Error(`Zielordner enthält bereits eine Präsentation: ${project}`);
      } catch (error) {
        if (error.code !== 'ENOENT') throw error;
      }
    }
    const entries = await fs.readdir(project, {withFileTypes: true});
    const unexpected = entries.filter(entry => !['assets', 'metadata'].includes(entry.name));
    if (unexpected.length) throw new Error(`Vorbereiteter Zielordner enthält unerwartete Einträge: ${unexpected.map(entry => entry.name).join(', ')}`);
    const metadata = path.join(project, 'metadata');
    try {
      const metadataFiles = await filesBelow(metadata);
      const protectedFiles = metadataFiles.filter(file => path.resolve(file) !== specPath);
      if (protectedFiles.length) {
        throw new Error(`Vorbereiteter Zielordner enthält bereits Metadaten: ${protectedFiles.map(file => path.relative(project, file)).join(', ')}`);
      }
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
  }
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
}
const baseCss = await fs.readFile(path.join(pluginRoot, 'assets', 'runtime', 'base.css'), 'utf8');
const runtime = await fs.readFile(path.join(pluginRoot, 'assets', 'runtime', 'deck-runtime.js'), 'utf8');
const studioVersion = (await readJson(path.join(pluginRoot, '.codex-plugin', 'plugin.json'))).version;

function renderLocalSlide(slide, index, total) {
  let html = String(slide.html || '');
  if (!/<section\b[^>]*\bclass=["'][^"']*\bslide\b/.test(html)) {
    throw new Error(`Folie ${index + 1}: slides[].html muss ein <section class="slide"> enthalten.`);
  }
  const values = {
    ...(slide.data || {}),
    page: `${String(index + 1).padStart(2, '0')} / ${String(total).padStart(2, '0')}`
  };
  html = html.replace(/\{\{([a-zA-Z0-9_-]+)\}\}/g, (_, key) => escapeHtml(values[key] ?? `[${key}]`));
  let editIndex = 0;
  html = html.replace(/data-edit(?!-id)/g, () => `data-edit-id="s${index + 1}-e${++editIndex}"`);
  const layoutId = slide.layoutId || slide.template || 'custom-local';
  return html.replace(
    /<section\b/,
    `<section data-slide="${index + 1}" data-template-id="${escapeHtml(layoutId)}"`
  );
}

const rendered = [];
const styles = [];
const templates = [];
const allowedOverlaps = [];
const usedAssets = new Set([
  'sora-700.woff2', 'sora-500.woff2', 'ibm-plex-sans-400.woff2',
  'ibm-plex-sans-600.woff2', 'ibm-plex-mono-600.woff2'
]);

for (let i = 0; i < spec.slides.length; i++) {
  const slide = spec.slides[i];
  if (slide.html) {
    const layoutId = slide.layoutId || slide.template || 'custom-local';
    templates.push(layoutId);
    allowedOverlaps.push({slide: i + 1, template: layoutId, pairs: slide.allowedOverlaps || []});
    for (const asset of slide.requiredAssets || []) usedAssets.add(asset);
    rendered.push(renderLocalSlide(slide, i, spec.slides.length));
    styles.push(String(slide.css || ''));
    continue;
  }
  throw new Error(`Folie ${i + 1}: html fehlt. BlankPresentationStudio verwendet keine Galerie-Templates.`);
}

const slidesHtml = await inlineIcons(rendered.join('\n'));

for (const asset of usedAssets) {
  const source = assetPath(path.join(pluginRoot, 'assets'), asset);
  const prepared = assetPath(path.join(project, 'assets'), asset);
  try {
    await fs.access(source);
  } catch (sourceError) {
    try { await fs.access(prepared); } catch {
      throw new Error(`Pflicht-Asset fehlt: ${asset}`);
    }
  }
}
for (const required of [
  path.join(pluginRoot, 'assets', 'runtime', 'edit-server.mjs'),
  path.join(pluginRoot, 'assets', 'project', 'edit-praesi.cmd.template')
]) await fs.access(required);

const deckData = {
  studioVersion,
  title: spec.title,
  slug: spec.slug || path.basename(project),
  language: spec.language || 'de',
  studio: 'BlankPresentationStudio',
  theme: spec.theme,
  styleDirection: spec.styleDirection,
  templates,
  customLayouts: spec.slides.flatMap((slide, index) => slide.html ? [index + 1] : []),
  assets: [...usedAssets],
  sources: spec.sources || [],
  notes: spec.slides.map(slide => ({
    title: slide.data?.title || slide.data?.section || slide.noteTitle || 'Notizen',
    bullets: slide.notes || []
  })),
  contentEdits: {},
  allowedOverlaps
};
const json = JSON.stringify(deckData).replace(/</g, '\\u003c');
const html = `<!doctype html><html lang="${escapeHtml(deckData.language)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(spec.title)}</title><style>${baseCss}
${themeCss}
${String(spec.css || '')}
.inline-icon svg{width:100%;height:100%;stroke:currentColor}
${styles.join('\n')}</style></head><body data-deck-id="${escapeHtml(deckData.slug)}" data-edit-enabled="true"><div class="deck-viewport"><main class="deck-stage">${slidesHtml}</main></div><div class="presentation-cursor" aria-hidden="true"></div><div class="edit-toolbar"><button id="saveEdits">Speichern</button><button id="exitEdit">Beenden</button></div><script id="deck-data" type="application/json">${json}</script><script>${runtime}</script></body></html>`;

for (const directory of ['assets', 'metadata/pdf', 'metadata/screenshots', 'tools']) {
  await fs.mkdir(path.join(project, directory), {recursive: true});
}
await fs.writeFile(path.join(project, 'index.html'), html, 'utf8');
await fs.writeFile(path.join(project, 'metadata', 'input.md'), String(spec.input || ''), 'utf8');
await fs.writeFile(path.join(project, 'metadata', 'storyboard.md'), String(spec.storyboard || ''), 'utf8');
await fs.writeFile(path.join(project, 'metadata', 'presentation.json'), JSON.stringify(deckData, null, 2) + '\n', 'utf8');
for (const asset of usedAssets) {
  const source = assetPath(path.join(pluginRoot, 'assets'), asset);
  const target = assetPath(path.join(project, 'assets'), asset);
  try {
    await fs.access(source);
    await fs.mkdir(path.dirname(target), {recursive: true});
    await fs.copyFile(source, target);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}
await fs.copyFile(path.join(pluginRoot, 'assets', 'runtime', 'edit-server.mjs'), path.join(project, 'tools', 'edit-server.mjs'));
await fs.copyFile(path.join(pluginRoot, 'assets', 'project', 'edit-praesi.cmd.template'), path.join(project, 'edit-praesi.cmd'));
console.log(`Erstellt: ${path.join(project, 'index.html')} (${spec.slides.length} Folien)`);
