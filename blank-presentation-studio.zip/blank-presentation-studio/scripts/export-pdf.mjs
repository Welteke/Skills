import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {parseArgs, resolveProjectPath} from './lib.mjs';
import {launchChromium} from './dependencies.mjs';

const args = parseArgs(process.argv);
if (!args.project) throw new Error('Aufruf: node export-pdf.mjs --project <ordner> [--output relativer-pfad.pdf]');
const project = path.resolve(args.project);
const output = resolveProjectPath(project, args.output, path.join('metadata', 'pdf', `${path.basename(project)}.pdf`));
await fs.mkdir(path.dirname(output), {recursive: true});
const browser = await launchChromium({headless: true});
const page = await browser.newPage({viewport: {width: 1920, height: 1080}});
await page.goto(pathToFileURL(path.join(project, 'index.html')).href);
await page.evaluate(()=>document.fonts.ready);
await page.evaluate(() => {
  document.body.classList.add('pdf-mode');
  document.querySelectorAll('.slide').forEach(slide => slide.classList.add('active'));
});
await page.pdf({
  path: output,
  width: '1920px',
  height: '1080px',
  printBackground: true,
  preferCSSPageSize: false,
  margin: {top: '0', right: '0', bottom: '0', left: '0'}
});
await browser.close();
console.log(`PDF: ${output}`);
