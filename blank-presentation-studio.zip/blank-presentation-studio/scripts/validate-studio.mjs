import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pluginRoot, readJson} from './lib.mjs';

const plugin = await readJson(path.join(pluginRoot, '.codex-plugin/plugin.json'));
const packageData = await readJson(path.join(pluginRoot, 'package.json'));
assert.equal(plugin.name, 'blank-presentation-studio');
assert.equal(plugin.interface.displayName, 'BlankPresentationStudio');
assert.equal(plugin.version, packageData.version);
const expected = ['blank-presentation-studio','presentation-create','presentation-update','presentation-enhance-motion','presentation-qa','presentation-create-handout','presentation-export-pdf','presentation-export-single-html'];
const directories = (await fs.readdir(path.join(pluginRoot, 'skills'), {withFileTypes:true})).filter(entry=>entry.isDirectory()).map(entry=>entry.name);
assert.deepEqual(directories.sort(), expected.sort());
for (const name of directories) {
  const directory = path.join(pluginRoot,'skills',name);
  const text = await fs.readFile(path.join(directory,'SKILL.md'),'utf8');
  const match = text.match(/^---\r?\nname: ([a-z0-9-]+)\r?\ndescription: ([^\r\n]+)\r?\n---/);
  assert.ok(match, `${name}: expected name/description frontmatter`);
  assert.equal(match[1],name);
  assert.ok(name.length<=64 && !name.includes('--'));
  assert.ok(match[2].length<=1024 && !/[<>]/.test(match[2]));
  assert.ok(!text.includes('[TODO:'));
  const ui = await fs.readFile(path.join(directory,'agents/openai.yaml'),'utf8');
  // These metadata files deliberately use only quoted scalar interface fields.
  assert.ok(ui.startsWith('interface:\n'));
  const fields = Object.fromEntries(ui.trim().split('\n').slice(1).map(line=>{
    const item=line.match(/^  (display_name|short_description|default_prompt): (".*")$/);
    assert.ok(item, `${name}: unsupported UI metadata form`);
    return [item[1], JSON.parse(item[2])];
  }));
  assert.ok(fields.short_description.length>=25 && fields.short_description.length<=64);
  assert.ok(fields.default_prompt.includes('$'+name));
  for (const [,reference] of text.matchAll(/`(\.\.\/\.\.\/references\/[^`]+)`/g)) await fs.access(path.resolve(directory,reference));
}
const schema = await fs.readFile(path.join(pluginRoot,'references/presentation-schema.md'),'utf8');
JSON.parse(schema.match(/```json\n([\s\S]*?)\n```/)[1]);
for (const asset of ['assets/runtime/base.css','assets/runtime/deck-runtime.js','assets/runtime/edit-server.mjs','assets/project/edit-praesi.cmd.template','assets/icons/TABLER-LICENSE.txt','assets/fonts/SORA-LICENSE.txt','assets/fonts/IBM-PLEX-SANS-LICENSE.txt','assets/fonts/IBM-PLEX-MONO-LICENSE.txt']) await fs.access(path.join(pluginRoot,asset));
for (const absent of ['template-gallery.html','assets/templates','assets/reference','scripts/web-publish.mjs','scripts/publish-zip.mjs','scripts/save-state.mjs','scripts/password-protect.mjs']) await assert.rejects(fs.access(path.join(pluginRoot,absent)));
console.log(`PASS: plugin metadata, ${directories.length} skills, UI metadata, schema example, references, resources and reduced feature scope.`);
