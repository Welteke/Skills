import fs from 'node:fs/promises';
import path from 'node:path';
import {parseArgs, resolveProjectPath} from './lib.mjs';

const args = parseArgs(process.argv);
if (!args.project) throw new Error('Aufruf: node export-single-html.mjs --project <ordner> [--output <relative-in-project.html>] [--force]');
const project = path.resolve(args.project);
const source = path.join(project, 'index.html');
const output = resolveProjectPath(project, args.output, path.join('metadata', 'single-html', `${path.basename(project)}.html`));
if (path.extname(output).toLowerCase() !== '.html') throw new Error(`Single-HTML-Ziel muss auf .html enden: ${output}`);
if (path.resolve(output) === path.resolve(source)) throw new Error('Der Single-HTML-Export darf die bearbeitbare index.html nicht ersetzen.');
try {
  await fs.access(output);
  if (!args.force) throw new Error(`Single-HTML-Export existiert bereits: ${output}. Zum Ersetzen --force verwenden.`);
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
}

const mimeTypes = new Map([
  ['.avif', 'image/avif'], ['.bmp', 'image/bmp'], ['.gif', 'image/gif'], ['.ico', 'image/x-icon'],
  ['.jpeg', 'image/jpeg'], ['.jpg', 'image/jpeg'], ['.png', 'image/png'], ['.svg', 'image/svg+xml'], ['.webp', 'image/webp'],
  ['.woff', 'font/woff'], ['.woff2', 'font/woff2'], ['.ttf', 'font/ttf'], ['.otf', 'font/otf'],
  ['.mp3', 'audio/mpeg'], ['.oga', 'audio/ogg'], ['.ogg', 'audio/ogg'], ['.wav', 'audio/wav'],
  ['.m4v', 'video/mp4'], ['.mp4', 'video/mp4'], ['.ogv', 'video/ogg'], ['.webm', 'video/webm'],
  ['.css', 'text/css'], ['.js', 'text/javascript'], ['.json', 'application/json'], ['.pdf', 'application/pdf']
]);
const embedded = new Map();
const isEmbedded = value => /^(?:data:|#|about:blank$)/i.test(value.trim());
const isRemote = value => /^(?:https?:|file:|blob:|javascript:|\/\/)/i.test(value.trim());

function splitReference(reference) {
  const match = String(reference).trim().match(/^([^?#]*)(\?[^#]*)?(#.*)?$/);
  return {pathname: match?.[1] || '', hash: match?.[3] || ''};
}

function resolveResource(reference, baseDirectory = project) {
  if (isEmbedded(reference)) return null;
  if (isRemote(reference) || path.isAbsolute(reference)) throw new Error(`Externe oder absolute Ressource kann nicht eingebettet werden: ${reference}`);
  const {pathname, hash} = splitReference(reference);
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { decoded = pathname; }
  const file = path.resolve(baseDirectory, decoded.replaceAll('/', path.sep));
  const relative = path.relative(project, file);
  if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error(`Ressource liegt außerhalb des Präsentationsordners: ${reference}`);
  return {file, hash};
}

async function asDataUrl(reference, baseDirectory = project) {
  const resolved = resolveResource(reference, baseDirectory);
  if (!resolved) return reference;
  const key = resolved.file.toLowerCase();
  let dataUrl = embedded.get(key);
  if (!dataUrl) {
    let content;
    try { content = await fs.readFile(resolved.file); } catch { throw new Error(`Ressource fehlt und kann nicht eingebettet werden: ${reference}`); }
    const mime = mimeTypes.get(path.extname(resolved.file).toLowerCase()) || 'application/octet-stream';
    dataUrl = `data:${mime};base64,${content.toString('base64')}`;
    embedded.set(key, dataUrl);
  }
  return dataUrl + resolved.hash;
}

async function replaceAsync(value, expression, replacer) {
  const matches = [...value.matchAll(expression)];
  if (!matches.length) return value;
  const replacements = await Promise.all(matches.map(match => replacer(...match)));
  let result = '';
  let cursor = 0;
  matches.forEach((match, index) => {
    result += value.slice(cursor, match.index) + replacements[index];
    cursor = match.index + match[0].length;
  });
  return result + value.slice(cursor);
}

async function inlineCss(css, baseDirectory = project) {
  return replaceAsync(css, /url\(\s*(['"]?)([^'"\)]+)\1\s*\)/gi, async (full, quote, reference) => {
    const clean = reference.trim();
    if (isEmbedded(clean)) return full;
    return `url("${await asDataUrl(clean, baseDirectory)}")`;
  });
}

async function inlineStylesheets(html) {
  return replaceAsync(html, /<link\b([^>]*\brel=["'][^"']*stylesheet[^"']*["'][^>]*)>/gi, async (full, attributes) => {
    const href = attributes.match(/\bhref\s*=\s*(["'])(.*?)\1/i)?.[2];
    if (!href) throw new Error(`Stylesheet-Link ohne href: ${full}`);
    const resolved = resolveResource(href);
    if (!resolved) return full;
    const css = await fs.readFile(resolved.file, 'utf8');
    return `<style data-inlined-from="${href.replaceAll('"', '&quot;')}">${await inlineCss(css, path.dirname(resolved.file))}</style>`;
  });
}

async function inlineScripts(html) {
  return replaceAsync(html, /<script\b([^>]*\bsrc\s*=\s*(["'])(.*?)\2[^>]*)>\s*<\/script>/gi, async (full, attributes, quote, reference) => {
    const resolved = resolveResource(reference);
    if (!resolved) return full;
    const code = (await fs.readFile(resolved.file, 'utf8')).replace(/<\/script/gi, '<\\/script');
    const cleanAttributes = attributes.replace(/\s*src\s*=\s*(["']).*?\1/i, '').replace(/\s*(?:integrity|crossorigin)\s*=\s*(["']).*?\1/gi, '');
    return `<script${cleanAttributes}>${code}</script>`;
  });
}

async function inlineSrcsets(html) {
  return replaceAsync(html, /\bsrcset\s*=\s*(["'])(.*?)\1/gi, async (full, quote, value) => {
    const candidates = value.split(',').map(candidate => candidate.trim()).filter(Boolean);
    const inlined = await Promise.all(candidates.map(async candidate => {
      const [reference, ...descriptor] = candidate.split(/\s+/);
      return `${await asDataUrl(reference)}${descriptor.length ? ` ${descriptor.join(' ')}` : ''}`;
    }));
    return `srcset=${quote}${inlined.join(', ')}${quote}`;
  });
}

async function inlineHtmlResources(html) {
  html = await replaceAsync(html, /\b(src|poster)\s*=\s*(["'])(.*?)\2/gi,
    async (full, attribute, quote, reference) => `${attribute}=${quote}${await asDataUrl(reference)}${quote}`);
  html = await replaceAsync(html, /<(image|use|object)\b([^>]*?)\b(href|data)\s*=\s*(["'])(.*?)\4([^>]*)>/gi,
    async (full, tag, before, attribute, quote, reference, after) => `<${tag}${before}${attribute}=${quote}${await asDataUrl(reference)}${quote}${after}>`);
  html = await replaceAsync(html, /<link\b([^>]*\brel=["'][^"']*(?:icon|apple-touch-icon)[^"']*["'][^>]*)>/gi, async (full, attributes) => {
    const hrefMatch = attributes.match(/\bhref\s*=\s*(["'])(.*?)\1/i);
    if (!hrefMatch) return full;
    const href = await asDataUrl(hrefMatch[2]);
    return `<link${attributes.replace(hrefMatch[0], `href=${hrefMatch[1]}${href}${hrefMatch[1]}`)}>`;
  });
  return inlineSrcsets(html);
}

function removeStudioFeatures(html) {
  html = html.replace(/<script\b[^>]*\bid=["']deck-data["'][^>]*>[\s\S]*?<\/script>/gi, '');
  html = html.replace(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi, (full, attributes, code) => (/\bBlankDeckRuntime\b/.test(code) ? '' : full));
  html = html.replace(/<(?:div|nav)\b[^>]*\bclass=["'][^"']*(?:edit-toolbar|presentation-cursor)[^"']*["'][^>]*>[\s\S]*?<\/(?:div|nav)>/gi, '');
  html = html.replace(/\sdata-edit-enabled\s*=\s*(["']).*?\1/gi, '').replace(/\sdata-edit-id\s*=\s*(["']).*?\1/gi, '').replace(/\scontenteditable\s*=\s*(["']).*?\1/gi, '');
  html = html.replace(/<style\b([^>]*)>([\s\S]*?)<\/style>/gi, (full, attributes, css) => {
    const cleaned = css.replace(/[^{}]*(?:edit-toolbar|editing|contenteditable|presenter-(?:shell|mode|current|next|notes|meta|actions|note-toolbar)|presentation-cursor)[^{}]*\{[^{}]*\}/gi, '');
    return `<style${attributes}>${cleaned}</style>`;
  });
  html = html.replace(/(<body\b[^>]*?)\sclass=(["'])(.*?)\2/i, (full, start, quote, classes) => {
    const clean = classes.split(/\s+/).filter(name => !['editing', 'presenter-mode'].includes(name)).join(' ');
    return clean ? `${start} class=${quote}${clean}${quote}` : start;
  });
  return html;
}

const exportCss = `<style id="blank-single-html-export-css">body{cursor:default}button,a{cursor:pointer}</style>`;
const exportRuntime = `<script id="blank-single-html-runtime">(()=>{class BlankSingleHtmlDeck{constructor(){this.slides=[...document.querySelectorAll('.slide')];this.stage=document.querySelector('.deck-stage');this.index=0;this.fragments=new Map;this.lastWheel=0;this.touchX=0;document.documentElement.style.setProperty('--slide-count',String(this.slides.length));this.slides.forEach((slide,index)=>slide.style.setProperty('--progress-index',String(index)));this.bind();this.scale();this.show(this.index,false)}bind(){addEventListener('resize',()=>this.scale());addEventListener('keydown',event=>{if(event.target?.closest('a,button,input,textarea,select'))return;if(['ArrowRight','PageDown',' '].includes(event.key)){event.preventDefault();this.next()}else if(['ArrowLeft','PageUp'].includes(event.key)){event.preventDefault();this.prev()}else if(event.key==='Home')this.show(0);else if(event.key==='End')this.show(this.slides.length-1)});addEventListener('wheel',event=>{if(Math.abs(event.deltaY)<12)return;const now=Date.now();if(now-this.lastWheel<450)return;this.lastWheel=now;event.deltaY>0?this.next():this.prev()},{passive:true});addEventListener('touchstart',event=>{this.touchX=event.changedTouches[0].screenX},{passive:true});addEventListener('touchend',event=>{const delta=event.changedTouches[0].screenX-this.touchX;if(delta<-70)this.next();if(delta>70)this.prev()},{passive:true});document.getElementById('prevBtn')?.addEventListener('click',()=>this.prev());document.getElementById('nextBtn')?.addEventListener('click',()=>this.next())}scale(){if(!this.stage)return;const factor=Math.min(innerWidth/1920,innerHeight/1080);this.stage.style.transform='translate('+((innerWidth-1920*factor)/2)+'px,'+((innerHeight-1080*factor)/2)+'px) scale('+factor+')'}parts(index){return[...(this.slides[index]?.querySelectorAll('[data-fragment]')||[])]}apply(index){const visible=this.fragments.get(index)||0;this.parts(index).forEach((element,part)=>element.classList.toggle('shown',part<visible))}show(index){this.index=Math.max(0,Math.min(index,this.slides.length-1));this.slides.forEach((slide,slideIndex)=>{const active=slideIndex===this.index;slide.classList.toggle('active',active);slide.classList.toggle('visible',active)});this.apply(this.index);const status=document.getElementById('slideStatus');if(status)status.textContent=(this.index+1)+' / '+this.slides.length}next(){const visible=this.fragments.get(this.index)||0;if(visible<this.parts(this.index).length){this.fragments.set(this.index,visible+1);this.apply(this.index);return}this.show(this.index+1)}prev(){const visible=this.fragments.get(this.index)||0;if(visible>0){this.fragments.set(this.index,visible-1);this.apply(this.index);return}this.show(this.index-1)}}addEventListener('DOMContentLoaded',()=>{window.blankDeck=new BlankSingleHtmlDeck})})();</script>`;

let html = await fs.readFile(source, 'utf8');
html = removeStudioFeatures(html);
html = await inlineStylesheets(html);
html = await inlineScripts(html);
html = await replaceAsync(html, /<style\b([^>]*)>([\s\S]*?)<\/style>/gi, async (full, attributes, css) => `<style${attributes}>${await inlineCss(css)}</style>`);
html = await inlineHtmlResources(html);
html = html.replace(/<\/head>/i, `${exportCss}</head>`).replace(/<body\b([^>]*)>/i, '<body$1 data-blank-export="single-html">').replace(/<\/body>/i, `${exportRuntime}</body>`);

const unresolved = [];
for (const match of html.matchAll(/\b(?:src|poster|srcset)\s*=\s*(["'])(.*?)\1/gi)) if (!/^data:/i.test(match[2])) unresolved.push(match[2]);
for (const match of html.matchAll(/url\(\s*(["']?)(.*?)\1\s*\)/gi)) if (!/^(?:data:|#)/i.test(match[2])) unresolved.push(match[2]);
if (/<script\b[^>]*\bsrc\s*=/i.test(html) || /<link\b[^>]*\brel=["'][^"']*stylesheet/i.test(html)) unresolved.push('externes Script oder Stylesheet');
if (unresolved.length) throw new Error(`Single-HTML-Export enthält nicht eingebettete Ressourcen: ${[...new Set(unresolved)].join(', ')}`);

await fs.mkdir(path.dirname(output), {recursive: true});
await fs.writeFile(output, html, 'utf8');
const inputSize = (await fs.stat(source)).size;
const outputSize = (await fs.stat(output)).size;
console.log(`Single-HTML-Export: ${output}`);
console.log(`Eingebettete Dateien: ${embedded.size}; Größe: ${inputSize} -> ${outputSize} Bytes`);
