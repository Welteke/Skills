import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {launchChromium} from './dependencies.mjs';
import {parseArgs, resolveProjectPath} from './lib.mjs';

const args = parseArgs(process.argv);
if (!args.project) throw new Error('Aufruf: node qa-handout.mjs --project <ordner>');
const project = path.resolve(args.project);
const handout = resolveProjectPath(project, args.handout, 'metadata/handout');
const htmlPath = path.join(handout, 'index.html');
const html = await fs.readFile(htmlPath, 'utf8');
const failures = [];
for (const bad of ['ÃƒÆ’Ã‚Â¤', 'ÃƒÆ’Ã‚Â¶', 'ÃƒÆ’Ã‚Â¼', 'ÃƒÆ’Ã…Â¸', 'ï¿½']) {
  if (html.includes(bad)) failures.push(`Kodierungsfehler gefunden: ${bad}`);
}
if (/(?:src|href)=["'](?:file:|[a-z]:\\|\/)/i.test(html)) failures.push('Absoluter lokaler Pfad gefunden');
if (/\b(?:1920px|1080px)\b/.test(html) || /class=["'][^"']*\bslide\b/.test(html)) {
  failures.push('Handout enthält feste Foliengeometrie');
}

const browser = await launchChromium({headless: true});
const pageErrors = [];
const page = await browser.newPage({viewport: {width: 1440, height: 1000}});
page.on('pageerror', error => pageErrors.push(error.message));
await page.goto(pathToFileURL(htmlPath).href);
await page.waitForLoadState('load');

async function inspectViewport(label) {
  const issues = await page.evaluate(() => {
    const out = [];
    if (document.documentElement.scrollWidth > innerWidth + 1) out.push(`Horizontaler Overflow: ${document.documentElement.scrollWidth}px bei ${innerWidth}px`);
    if (!document.querySelector('main h2')) out.push('Keine Kapitelüberschrift gefunden');
    for (const image of document.images) {
      if (!image.complete || image.naturalWidth === 0) out.push(`Bild fehlt: ${image.getAttribute('src')}`);
    }
    for (const element of document.querySelectorAll('h1,h2,h3,h4,p,li,dt,dd,button')) {
      const rect = element.getBoundingClientRect();
      if (element.closest('.chapter-tabs')) continue;
      if (rect.right > innerWidth + 1 || rect.left < -1) out.push(`Element außerhalb: ${element.tagName}.${element.className}`);
    }
    return out;
  });
  for (const issue of issues) failures.push(`${label}: ${issue}`);
}

await inspectViewport('Desktop');
await fs.mkdir(path.join(handout, 'screenshots'), {recursive: true});
await page.screenshot({path: path.join(handout, 'screenshots', 'handout-desktop.png'), fullPage: true});

await page.setViewportSize({width: 390, height: 844});
await inspectViewport('Mobil');
await page.screenshot({path: path.join(handout, 'screenshots', 'handout-mobile.png'), fullPage: true});
for (const error of pageErrors) failures.push(`JavaScript-Fehler: ${error}`);
await browser.close();

const result = {ok: failures.length === 0, failures};
await fs.writeFile(path.join(handout, 'qa-results.json'), JSON.stringify(result, null, 2) + '\n', 'utf8');
console.log(JSON.stringify(result, null, 2));
if (failures.length) process.exitCode = 1;
