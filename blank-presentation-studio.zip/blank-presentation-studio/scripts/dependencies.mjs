import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {createRequire} from 'node:module';

const localRequire = createRequire(import.meta.url);

export function loadDependency(name) {
  try {
    return localRequire(name);
  } catch (localError) {
    const runtimesRoot = path.join(os.homedir(), '.cache', 'codex-runtimes');
    let runtimes = [];
    try {
      runtimes = fs.readdirSync(runtimesRoot, {withFileTypes: true})
        .filter(entry => entry.isDirectory())
        .map(entry => entry.name)
        .sort((a, b) => b.localeCompare(a));
    } catch {}

    for (const runtime of runtimes) {
      const modulesRoot = path.join(
        runtimesRoot,
        runtime,
        'dependencies',
        'node',
        'node_modules'
      );
      const candidates = [path.join(modulesRoot, name)];
      const pnpmRoot = path.join(modulesRoot, '.pnpm');
      try {
        for (const entry of fs.readdirSync(pnpmRoot, {withFileTypes: true})) {
          if (entry.isDirectory() && entry.name.startsWith(`${name}@`)) {
            candidates.unshift(path.join(pnpmRoot, entry.name, 'node_modules', name));
          }
        }
      } catch {}
      for (const candidate of candidates) {
        if (!fs.existsSync(path.join(candidate, 'package.json'))) continue;
        try {
          return localRequire(candidate);
        } catch {}
      }
    }
    throw new Error(
      `Abhängigkeit "${name}" wurde weder lokal noch in der Codex-Desktop-Runtime gefunden. ` +
      `Ursprünglicher Fehler: ${localError.message}`
    );
  }
}

export async function launchChromium(options = {}) {
  const {chromium} = loadDependency('playwright');
  if (process.env.BLANK_CHROMIUM_EXECUTABLE) {
    return chromium.launch({...options, executablePath: process.env.BLANK_CHROMIUM_EXECUTABLE});
  }
  try { return await chromium.launch(options); } catch (error) {
    if (!error.message.includes("Executable doesn't exist")) throw error;
    // Codex's bundled Playwright may be newer than the installed browser cache.
    const cache = process.env.PLAYWRIGHT_BROWSERS_PATH || (process.platform === 'win32'
      ? path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'ms-playwright')
      : process.platform === 'darwin' ? path.join(os.homedir(), 'Library', 'Caches', 'ms-playwright')
      : path.join(os.homedir(), '.cache', 'ms-playwright'));
    let entries;
    try { entries = fs.readdirSync(cache).filter(name => /^chromium-\d+$/.test(name)).sort((a,b) => b.localeCompare(a, undefined, {numeric:true})); }
    catch { throw error; }
    for (const entry of entries) {
      const relative = process.platform === 'win32' ? 'chrome-win64/chrome.exe'
        : process.platform === 'darwin' ? 'chrome-mac/Chromium.app/Contents/MacOS/Chromium' : 'chrome-linux/chrome';
      const executablePath = path.join(cache, entry, relative);
      if (fs.existsSync(executablePath)) return chromium.launch({...options, executablePath});
    }
    throw error;
  }
}
