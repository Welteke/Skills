import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {pathToFileURL, fileURLToPath} from 'node:url';

// Outputs remain in a uniquely created temporary folder for visual inspection.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const {launchChromium} = await import(pathToFileURL(path.join(root, 'scripts/dependencies.mjs')));
const temporary = await fs.mkdtemp(path.join(os.tmpdir(), 'blank-studio-test-'));
const project = path.join(temporary, 'deck');
const theme = {accent:'#703820',accent2:'#315345',ink:'#202020',muted:'#555555',background:'#faf8f2',surface:'#ffffff',fonts:{display:'Georgia,serif',body:'Arial,sans-serif',mono:'monospace'}};
const spec = {
 title:'Gemeinsam weiter',slug:'neutral-review',language:'de',input:'Orientierung, Prozess, Entscheidung.',
 storyboard:'Drei Folien mit warmer Typografie und einem schrittweisen Prozess.',
 styleDirection:'Warmer Editorial-Stil mit Serifentiteln und grünen Prozesssymbolen',theme,
 css:'.slide{padding:110px}.slide h1,.slide h2{font:700 76px/1.15 var(--display);max-width:1500px}.slide p{font:400 36px/1.5 var(--body);margin-top:55px;max-width:1400px}.process .steps{display:flex;gap:44px;margin-top:110px}.process article{width:500px;padding:45px;background:var(--surface);border:2px solid var(--accent-2)}.process article h3{font:600 36px/1.2 var(--body)}.process .inline-icon{width:70px;height:70px;color:var(--accent-2);margin-bottom:45px}',
 slides:[
  {layoutId:'opening',html:'<section class="slide opening"><h1 data-edit>{{title}}</h1><p class="reveal">Ein klarer Rahmen für die nächsten Schritte.</p><div class="page-no">{{page}}</div></section>',data:{title:'Gemeinsam weiter'},notes:['Orientierung geben.']},
  {layoutId:'process',html:'<section class="slide process"><h2 data-edit>{{title}}</h2><div class="steps"><article><div data-icon="search"></div><h3>Verstehen</h3></article><article data-fragment><div data-icon="check"></div><h3>Entscheiden</h3></article></div><div class="page-no">{{page}}</div></section>',data:{title:'Der nächste Schritt'},notes:['Verstehen.','KLICK: Entscheiden.']},
  {layoutId:'closing',html:'<section class="slide closing"><h2 data-edit>{{title}}</h2><p>Die Entscheidung gemeinsam festhalten.</p><div class="page-no">{{page}}</div></section>',data:{title:'Ein gemeinsames Ziel'},notes:['Abschluss.']}
 ]
};
const specPath = path.join(temporary, 'spec.json');
await fs.writeFile(specPath, JSON.stringify(spec));
async function run(script, args=[], success=true) {
 const result=await new Promise((resolve,reject)=>{
  const child=spawn(process.execPath,[path.join(root,'scripts',script),...args],{windowsHide:true});
  let output=''; child.stdout.on('data',data=>output+=data);child.stderr.on('data',data=>output+=data);
  child.on('error',reject);child.on('exit',code=>resolve({code,output}));
 });
 assert.equal(result.code===0,success,result.output);
 return result.output;
}
await run('build-deck.mjs',['--project',project,'--spec',specPath]);
await run('build-deck.mjs',['--project',project,'--spec',specPath],false);
for (const forbidden of ['template-gallery.url','metadata/publish','metadata/snapshots']) await assert.rejects(fs.access(path.join(project,forbidden)));
const html = await fs.readFile(path.join(project,'index.html'),'utf8');
assert.ok(!/ATE|ate-logo|--magenta|reference-layouts|template-gallery/.test(html));
const meta=JSON.parse(await fs.readFile(path.join(project,'metadata/presentation.json'),'utf8'));
assert.deepEqual(meta.theme,theme);
await run('export-pdf.mjs',['--project',project,'--output','../outside.pdf'],false);
await run('qa-deck.mjs',['--project',project]);
const browser=await launchChromium({headless:true});
let server;
try {
 const context=await browser.newContext({viewport:{width:1366,height:768}});
 const page=await context.newPage();
 const errors=[];page.on('pageerror',error=>errors.push(error.message));
 const url=pathToFileURL(path.join(project,'index.html')).href;
 await page.goto(url);
 await page.waitForFunction(()=>window.blankDeck?.slides.length===3);
 assert.match(await page.locator('h1').evaluate(element=>getComputedStyle(element).fontFamily),/Georgia/);
 await page.keyboard.press('ArrowRight');
 assert.equal(await page.locator('.slide.active').getAttribute('data-slide'),'2');
 await page.keyboard.press('ArrowRight');assert.equal(await page.locator('[data-fragment].shown').count(),1);
 await page.keyboard.press('ArrowLeft');assert.equal(await page.locator('[data-fragment].shown').count(),0);
 await page.mouse.wheel(0,-300);await page.waitForTimeout(100);
 assert.equal(await page.locator('.slide.active').getAttribute('data-slide'),'1');
 const presenter=await page.context().newPage();
 await presenter.setViewportSize({width:1600,height:1000});
 await presenter.goto(url+'?presenter=1');
 await presenter.waitForSelector('.presenter-shell');
 await page.keyboard.press('ArrowRight');
 await presenter.waitForFunction(()=>window.blankDeck.index===1);
 assert.equal(await presenter.locator('.presenter-next .slide').getAttribute('data-slide'),'3');
 await presenter.locator('[data-note-action="add"]').click();
 assert.equal(await presenter.locator('#presenterNotes li').count(),3);
 await presenter.close();
 await page.keyboard.press('e');assert.equal(await page.locator('body.editing').count(),1);
 await page.locator('#exitEdit').click();
 // Persistent editing through the bundled local server.
 const port=await new Promise((resolve,reject)=>{
  server=spawn(process.execPath,[path.join(project,'tools/edit-server.mjs')],{env:{...process.env,BLANK_EDIT_PORT:'0'},windowsHide:true});
  let output='';server.stdout.on('data',data=>{output+=data;const match=output.match(/127\.0\.0\.1:(\d+)/);if(match)resolve(Number(match[1]));});
  server.on('error',reject);server.on('exit',code=>reject(new Error('Edit server exited '+code)));
 });
 await page.goto('http://127.0.0.1:'+port);
 await page.keyboard.press('e');
 await page.locator('[data-edit-id]').first().fill('Gemeinsam gestalten');
 await page.locator('#saveEdits').click();
 await page.waitForTimeout(250);await page.reload();
 assert.equal(await page.locator('h1').textContent(),'Gemeinsam gestalten');
 assert.equal(errors.length,0,errors.join('\n'));
 await run('export-pdf.mjs',['--project',project]);
 const pdf=await fs.readFile(path.join(project,'metadata/pdf/deck.pdf'));
 assert.equal(pdf.subarray(0,4).toString(),'%PDF');
 assert.equal((pdf.toString('latin1').match(/\/Type \/Page\b/g)||[]).length,3);
 const handoutSpec=path.join(temporary,'handout.json');
 await fs.writeFile(handoutSpec,JSON.stringify({mode:'full',tabs:true,chapters:spec.slides.map((slide,index)=>({title:slide.data.title,sourceSlides:[index+1],blocks:[{type:'text',paragraphs:slide.notes}]}))}));
 await run('build-handout.mjs',['--project',project,'--spec',handoutSpec]);
 await run('qa-handout.mjs',['--project',project]);
 await page.goto(pathToFileURL(path.join(project,'metadata/handout/index.html')).href);
 assert.equal(await page.locator('.brand-wordmark').count(),0);
 assert.match(await page.locator('h1').evaluate(element=>getComputedStyle(element).fontFamily),/Georgia/);
 await page.locator('[role=tab]').nth(2).click();assert.equal(await page.locator('.chapter:not([hidden]) h2').textContent(),spec.slides[2].data.title);
 await page.emulateMedia({media:'print'});
 assert.equal(await page.locator('.chapter:visible').count(),3);
 await page.emulateMedia({media:'screen'});
 await run('export-single-html.mjs',['--project',project]);
 const single=path.join(project,'metadata/single-html/deck.html');
 const singleHtml=await fs.readFile(single,'utf8');
 assert.ok(singleHtml.includes('data:font/woff2;base64,'));
 assert.ok(!/deck-data|BlankDeckRuntime|BroadcastChannel|data-edit-id=|edit-toolbar/.test(singleHtml));
 await fs.rename(path.join(project,'assets'),path.join(project,'assets-unavailable'));
 const portable=await browser.newPage({viewport:{width:1280,height:720}});
 const requests=[];portable.on('request',request=>requests.push(request.url()));portable.on('pageerror',error=>errors.push(error.message));
 await portable.goto(pathToFileURL(single).href+'?presenter=1');
 await portable.keyboard.press('p');await portable.keyboard.press('e');
 assert.equal(await portable.locator('.presenter-shell,[contenteditable=true]').count(),0);
 await portable.keyboard.press('ArrowRight');await portable.keyboard.press('ArrowRight');
 assert.equal(await portable.locator('[data-fragment].shown').count(),1);
 await portable.keyboard.press('ArrowRight');assert.equal(await portable.locator('.slide.active').getAttribute('data-slide'),'3');
 assert.equal(requests.filter(url=>!url.startsWith('data:')).length,1);
 assert.equal(errors.length,0,errors.join('\n'));
 // A second, unrelated design verifies that deck CSS and handout fonts are not fixed.
 const alternative={...spec,theme:{...theme,background:'#151515',ink:'#ffffff',muted:'#dddddd',fonts:{display:'Arial,sans-serif',body:'Arial,sans-serif',mono:'monospace'}},styleDirection:'Dark typographic design',slides:[spec.slides[0]]};
 await fs.writeFile(specPath,JSON.stringify(alternative));
 const other=path.join(temporary,'alternative');await run('build-deck.mjs',['--project',other,'--spec',specPath]);await run('qa-deck.mjs',['--project',other]);
 console.log('PASS: creation, independent styles, icons, QA, navigation, fragments, Presenter sync, persistent editor, handout desktop/mobile/print, PDF and offline single HTML.');
 console.log('Visual inspection artifacts: '+temporary);
} finally {server?.kill();await browser.close();}
