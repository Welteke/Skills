# Choose a deck style

Reuse style decisions already provided in the conversation. Ask only for missing preferences that materially change the result.

1. When no direction is provided, ask whether the user has colors, typography, branding or a visual reference, or would like suggestions.
2. If they have none or ask for suggestions, propose two or three directions suited to the content, audience and setting. Describe concrete palette, typography, layout and image/diagram treatment. Do not present a fixed recurring gallery of styles.
3. Recommend one direction with a short reason. Obtain the choice with storyboard approval before building unless the user explicitly delegates the decision or requests direct creation.
4. Record the chosen direction in the storyboard and `styleDirection`. Store the six colors and three font stacks in `theme`. Set layouts and optional CSS per deck. No font, color, logo, decorative footer or component shape is prescribed globally.

Bundled Sora, IBM Plex Sans and IBM Plex Mono are available offline. System fonts and supplied local font files are also valid. Define supplied fonts with deck-local `@font-face` and list the files in `requiredAssets`. Do not use remote CDNs.

For animation, use an already chosen intensity. Otherwise the motion skill asks for subtle, dynamic or cinematic. A new deck can agree on intensity with its style and storyboard. Handouts inherit the deck theme and translate its visual language into responsive reading flow.
