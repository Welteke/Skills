# Presentation project schema

All artifacts stay inside the project:

```text
<slug>/
  index.html
  edit-praesi.cmd
  assets/
  tools/edit-server.mjs
  metadata/
    input.md
    storyboard.md
    presentation.json
    qa-results.json
    screenshots/
    pdf/
    handout/
    single-html/
```

The builder accepts this spec shape. Colors and font stacks below are examples, not a preset:

```json
{
  "title": "Project review",
  "slug": "project-review",
  "language": "en",
  "input": "Original user input",
  "storyboard": "Approved story and style",
  "sources": [],
  "styleDirection": "Warm editorial design with clear typographic hierarchy",
  "theme": {
    "accent": "#7a351a", "accent2": "#365b48",
    "ink": "#222222", "muted": "#555555",
    "background": "#faf8f2", "surface": "#ffffff",
    "fonts": {"display": "Georgia,serif", "body": "Arial,sans-serif", "mono": "monospace"}
  },
  "css": ".slide{padding:90px} h1{font:700 76px/1.1 var(--display)}",
  "slides": [{
    "layoutId": "opening",
    "html": "<section class=\"slide opening\"><h1 data-edit>{{title}}</h1><div class=\"page-no\">{{page}}</div></section>",
    "css": ".opening h1{max-width:1400px}",
    "data": {"title": "Project review"},
    "notes": ["Opening note"],
    "requiredAssets": [],
    "allowedOverlaps": []
  }]
}
```

Every slide must use deck-local HTML with one `<section class="slide">`. There is no `template` form. Scope slide CSS with a unique local class. `data-edit` becomes a stable editor ID; `{{key}}` escapes a value from `data`. `{{page}}` supplies the page count. Include a visible `.page-no`; no decorative footer strip is required.

For icons use `<div data-icon="check"></div>` and select names from `assets/icons/tabler/`. The builder embeds the SVG and rejects unknown names. Set dimensions and color on its container with deck-local CSS.

List local media and custom font paths below `assets/` in `requiredAssets`. Put supplied files there before building. Missing required resources block creation. Bundled font files are available but their font families are not selected automatically. `spec.css` supplies deck-wide styles.

Use `data-fragment` for click steps and matching `KLICK:` notes. `.reveal` and `.delay-1` through `.delay-3` provide optional entrances. Custom animations must stop on inactive slides, behave predictably on revisits and show their final static state in `.pdf-mode` and print.

Metadata records `studio: "BlankPresentationStudio"`, `studioVersion`, title, slug, language, styleDirection, theme, layout IDs in the runtime-compatible `templates` field, customLayouts, assets, sources, notes, contentEdits and allowedOverlaps. The `templates` field tracks authored layout IDs; it does not refer to a bundled library. Update metadata, storyboard and HTML together. Preserve input and append subsequent source input with a date.

The editable deck supports E for editing and P for Presenter mode. Start `edit-praesi.cmd` for persistent editing via the local server.

Handouts live under `metadata/handout/` with HTML, handout metadata, QA and desktop/mobile screenshots. The handout spec uses short/full mode, chapters with sourceSlides and blocks, and optional theme, fonts, themeCss, brandLabel and tabs. Colors/fonts inherit from the deck; brandLabel is only for requested user branding.

Single HTML exports embed local assets and remove notes, Presenter and editing. They never replace the source deck. PDFs are 1920×1080 per page with final animation states and no Presenter UI. Explicit output paths must stay inside the project.
