# QA policy

Run Chromium QA before declaring a deck complete, exporting PDF, or exporting single HTML. Block on:

- overflow beyond the 1920×1080 stage;
- undeclared intersections between content boxes;
- spacing that damages readability or grouping;
- text contrast below 3:1 on a calculable solid background, especially light or white text on white or very light surfaces;
- broken or absolute local asset paths;
- missing assets, wrong slide numbers, or navigation failures;
- mojibake patterns such as `Ã¤`, `Ã¶`, `Ã¼`, `ÃŸ`, or replacement characters;
- presenter synchronization failures;
- fragments that are not fully visible in PDF mode.
- content slides whose meaningful composition is unintentionally confined to the upper area while a large inert block remains below;
- visually underdeveloped content slides where the hierarchy is hard to scan and relevant icons, a diagram, or another meaningful visual anchor would materially improve it.

Intentional overlaps must be declared by selector pairs in a deck-local slide's `allowedOverlaps`. Render screenshots for every slide at 1920×1080. Test only Chromium unless the user reports a browser-specific concern.

Inspect contrast visually on every screenshot, including text over images, gradients, SVGs, and overlapping decorative surfaces. The automated solid-background check cannot reliably sample these complex backgrounds. Use `data-qa-contrast-ignore` only for a manually verified exception on a complex visual background, never to suppress an actually unreadable text/background combination.

For HTML handouts, run `qa-handout.mjs` instead of slide QA. Inspect the full desktop and mobile screenshots. Block on horizontal overflow, broken images, absolute local paths, JavaScript errors, mojibake, or remnants of fixed 1920×1080 slide geometry. Verify print flow and visual contrast manually. A full handout must reference every source slide in `handout.json`; a short handout may select only the core story.

For a single-HTML export, first require passing slide QA, then open the exported file directly through a local `file:` URL with the project assets unavailable. Block on any network or file request other than the HTML document, missing images or fonts, JavaScript errors, broken scaling/navigation/fragments, or remaining editing, Presenter, notes, synchronization, and deck-metadata code.

Also inspect the visual balance of every screenshot. Judge whitespace by composition, not by a fixed fill percentage: whitespace may separate groups and create focus, but a large unused lower region is a failure when it results only from undersized, top-heavy, or poorly distributed content. Fix it by recomposing meaningful elements rather than adding invented content or arbitrary decoration. A deliberately sparse slide of any type remains valid when its hierarchy, visual weight, and purpose are clear. Do not require icons or diagrams when typography and spacing already communicate the message.

