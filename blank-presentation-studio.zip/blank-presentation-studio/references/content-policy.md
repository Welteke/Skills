# Content policy

- Preserve claims, facts, numbers, links, and intent from the input.
- Correct spelling, grammar, punctuation, and mojibake. Always use UTF-8 and real German characters.
- Restructure, shorten, headline, and distribute content across slides. Do not invent facts or examples.
- Mark missing essential content in the storyboard.
- Research, image search, and image generation require an explicit request.
- Ask for useful user images. Copy supplied files into `assets/` and reference them relatively.
- Prefer a relevant Tabler icon over letters or emoji. Use icons as semantic visual anchors for clearly iconizable cards, steps, benefits, risks, channels, or key concepts when they improve scanning. Keep icon style, scale, color treatment, and alignment consistent within a slide; do not repeat generic icons without meaning or use them merely to fill gaps. Create a custom icon only after a documented unsuccessful search or an explicit request.
- Create accurate HTML/SVG diagrams from supplied relationships or numbers when useful.
- Speaker notes are short bullets close to the original input, cover all assigned details, and mark fragments as `KLICK: ...`.
- Start every slide from its content architecture: decide the hierarchy, semantic groups, and useful number of boxes before designing the layout.
- Use the usable slide height deliberately. Recompose layouts whose meaningful content is unintentionally confined to the upper area while a large inert block remains below. Prefer larger or better-distributed content, an adjusted grid, or a meaningful image, diagram, icon group, or visual anchor over arbitrary decoration. A deliberately sparse slide of any type is valid when its hierarchy, visual weight, and purpose are clear. Icons and diagrams are optional tools, not quotas.

- Design all slides locally from the content hierarchy and selected style. No preset layouts, mandatory logo positions, gradient footers or branding colors. Local bundled fonts are optional resources, not a required font choice.
